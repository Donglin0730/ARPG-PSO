# ARPG-PSO 基站部署实验代码目录

## 目录结构

```text
ARPG-PSO/
├─ model.py                         通信模型、SINR、覆盖率和目标函数
├─ tetromino_generator.py           生成重点区域掩码
├─ exp_config.py                      算法集合与正式实验规模
├─ exp_utils.py                      场景配置和最终指标复算
├─ iterations.py                    函数评价次数核算工具
├─ comparetime.py                   等时间消融结果汇总入口
├─ wilcoxon.py                      Wilcoxon-Holm统计函数导出入口
├─ requirements.txt                 Python依赖
├─ 算法代码/
│  ├─ PSO/PSO.py                    标准PSO
│  ├─ MPSO/MPSO.py                  MPSO
│  ├─ CLPSO/CLPSO.py                CLPSO
│  ├─ DMS-PSO/DMS_PSO.py            DMS-PSO
│  ├─ SPSO/SPSO.py                  SPSO
│  ├─ MPSORL/MPSORL.py              MPSORL
│  ├─ AFMPSO/AFMPSO.py              AFMPSO
│  ├─ AMSEPSO/AMSEPSO.py            AMSEPSO
│  ├─ FHPSO/FHPSO.py                FHPSO
│  ├─ ARPG-PSO/ARPG_PSO.py          ARPG-PSO
│  ├─ ARPG-PSO/ablation.py     ARPG-PSO消融版本
│  ├─ 公共组件/pso_base.py           共用PSO基础设施
│  ├─ 公共组件/mappo.py              MAPPO网络组件
│  └─ registry.py                    算法名称与实现类映射
├─ 实验代码/
│  ├─ 主场景与六场景/               等函数评价次数实验
│  ├─ 消融实验/                     等时间消融实验
│  └─ 跨布局实验/                   跨布局鲁棒性实验
├─ 统计分析/                         论文表格和统计分析入口
├─ 绘图/                             图6～14绘图入口
└─ README.md                         本说明
```
