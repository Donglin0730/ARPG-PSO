# -*- coding: utf-8 -*-
import numpy as np

# 7 种标准俄罗斯方块, 用相对坐标(行, 列)表示
TETROMINOES = {
    'I': [(0, 0), (0, 1), (0, 2), (0, 3)],
    'O': [(0, 0), (0, 1), (1, 0), (1, 1)],
    'T': [(0, 0), (0, 1), (0, 2), (1, 1)],
    'S': [(0, 1), (0, 2), (1, 0), (1, 1)],
    'Z': [(0, 0), (0, 1), (1, 1), (1, 2)],
    'J': [(0, 0), (1, 0), (1, 1), (1, 2)],
    'L': [(0, 2), (1, 0), (1, 1), (1, 2)],
}


def _rotate(cells):
    """把方块顺时针旋转 90 度。"""
    rotated = [(c, -r) for (r, c) in cells]
    min_r = min(r for r, _ in rotated)
    min_c = min(c for _, c in rotated)
    return [(r - min_r, c - min_c) for (r, c) in rotated]


def _random_piece(rng):
    name = rng.choice(list(TETROMINOES.keys()))
    cells = TETROMINOES[name]
    for _ in range(rng.integers(0, 4)):
        cells = _rotate(cells)
    return cells


def generate_special_area(size=50,
                          target_ratio=0.30,
                          num_clusters=6,
                          cluster_sigma=6.0,
                          seed=42):
    """
    生成 size x size 的 0/1 掩码, 1 表示重点区域。

    target_ratio  : 重点区域占整张图的目标比例 (城市里重点区域约占 30%)
    num_clusters  : 城市热点(街区中心)个数, 越少越集中
    cluster_sigma : 方块围绕热点散布的标准差(网格), 越小越紧凑
    """
    rng = np.random.default_rng(seed)
    grid = np.zeros((size, size), dtype=int)

    # 随机选取若干热点中心 (避免贴边)
    margin = int(size * 0.12)
    centers = []
    for _ in range(num_clusters):
        cx = rng.integers(margin, size - margin)
        cy = rng.integers(margin, size - margin)
        centers.append((cx, cy))

    target_cells = int(size * size * target_ratio)
    placed = 0
    attempts = 0
    max_attempts = target_cells * 60

    while placed < target_cells and attempts < max_attempts:
        attempts += 1
        # 选一个热点, 在其周围按高斯分布取落点
        cx, cy = centers[rng.integers(0, num_clusters)]
        r0 = int(np.clip(rng.normal(cx, cluster_sigma), 0, size - 1))
        c0 = int(np.clip(rng.normal(cy, cluster_sigma), 0, size - 1))

        piece = _random_piece(rng)
        coords = [(r0 + dr, c0 + dc) for (dr, dc) in piece]

        # 越界则放弃
        if any(r < 0 or r >= size or c < 0 or c >= size for r, c in coords):
            continue

        for (r, c) in coords:
            if grid[r, c] == 0:
                grid[r, c] = 1
                placed += 1

    return grid


if __name__ == "__main__":
    area = generate_special_area()
    print("重点区域占比: %.1f%%" % (100.0 * area.sum() / area.size))
