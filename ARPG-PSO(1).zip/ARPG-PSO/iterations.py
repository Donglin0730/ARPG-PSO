from exp_config import FE_BUDGET, PAPER_ALGORITHMS, PARTICLES, TARGET


def evaluation_schedule(label: str, particles: int, budget: int) -> dict:
    """返回完整更新轮次能够消耗的函数评价次数。

    各优化器均不在构造函数中单独调用目标函数。标准 PSO 及其变体
    每轮评价当前的 N 个位置；ARPG-PSO 每轮依次评价当前种群、PSO
    基础候选和策略增强候选，因此每轮恰好使用 3N 次。
    """
    initial_cost = 0
    update_cost = 3 * particles if label == TARGET else particles
    updates = budget // update_cost
    used = initial_cost + updates * update_cost
    return {
        "algorithm": "ARPG-PSO" if label == TARGET else label,
        "initial_fes": initial_cost,
        "fes_per_update": update_cost,
        "complete_updates": updates,
        "actual_fes": used,
        "unused_fes": budget - used,
    }


if __name__ == "__main__":
    headers = (
        "algorithm", "initial_fes", "fes_per_update", "complete_updates",
        "actual_fes", "unused_fes",
    )
    print(" ".join(f"{item:>17}" for item in headers))
    for algorithm in PAPER_ALGORITHMS:
        row = evaluation_schedule(algorithm, PARTICLES, FE_BUDGET)
        print(" ".join(f"{str(row[item]):>17}" for item in headers))
