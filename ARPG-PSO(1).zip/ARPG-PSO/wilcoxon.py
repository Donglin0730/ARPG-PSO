from 统计分析.ablation_stats import holm, paired_tests

__all__ = ["holm", "paired_tests"]


if __name__ == "__main__":
    print(
        "本文件提供 holm() 和 paired_tests()。完整统计请运行：\n"
        "  python comparetime.py --scenario 0dB_M20_10秒\n"
        "  python -m 统计分析.coverage_stats"
    )
