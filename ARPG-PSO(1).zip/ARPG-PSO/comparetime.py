from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


SCENARIOS = ("0dB_M20_10秒", "3dB_M10_10秒", "3dB_M10_30秒")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--scenario", choices=SCENARIOS, required=True)
    parser.add_argument("--source-root", default="示例结果/等时间消融")
    parser.add_argument("--output-root", default="实验结果/等时间统计")
    args = parser.parse_args()

    source = Path(args.source_root) / args.scenario
    output = Path(args.output_root) / args.scenario
    output.mkdir(parents=True, exist_ok=True)
    raw = source / "raw_results.csv"
    history = source / "time_histories.csv"
    if not raw.exists():
        raw = source / "03_四组消融_20次独立运行.csv"
    if not history.exists():
        interval = "每2秒" if "30秒" in args.scenario else "每秒"
        history = source / f"04_{interval}收敛轨迹.csv"
    subprocess.run([
        sys.executable, "-m", "统计分析.ablation_stats",
        "--input", str(raw),
        "--history", str(history),
        "--output", str(output),
        "--no-figure-title",
    ], check=True)


if __name__ == "__main__":
    main()
