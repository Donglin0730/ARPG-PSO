# -*- coding: utf-8 -*-
from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from exp_config import DISPLAY_LABELS, PAPER_ALGORITHMS, TARGET


ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "示例结果" / "论文绘图数据"
OUTPUT = ROOT / "生成图表"

ORDER = list(PAPER_ALGORITHMS)
PLOT_ORDER = [DISPLAY_LABELS.get(name, name) for name in ORDER]
ABLATION_ORDER = ["Base-only", "Frozen-Actor", "No-selection", "ARPG-PSO"]

COLORS = {
    "PSO": "#6FA8DC", "MPSO": "#F6B26B", "CLPSO": "#93C47D",
    "DMS-PSO": "#B58A7A", "SPSO": "#D5CF6A", "MPSORL": "#A6A6A6",
    "AFMPSO": "#D98BC3", "AMSEPSO": "#76C9D4", "FHPSO": "#E06666",
    TARGET: "#A984D1", "ARPG-PSO": "#A984D1", "Base-only": "#A7B0B5",
    "Frozen-Actor": "#86A9C8", "No-selection": "#E9AD72",
}
MARKERS = {name: marker for name, marker in zip(
    PLOT_ORDER, ["D", "o", "^", ">", "h", "*", "P", "s", "v", "<"]
)}
MARKERS.update({
    "Base-only": "*", "Frozen-Actor": "s", "No-selection": "o",
    "ARPG-PSO": "^",
})


def configure_style() -> None:
    plt.rcParams.update({
        "font.family": "serif",
        "font.serif": ["Times New Roman", "DejaVu Serif"],
        "font.size": 11,
        "axes.titlesize": 13,
        "axes.labelsize": 11,
        "axes.linewidth": 1.0,
        "lines.linewidth": 1.8,
        "xtick.labelsize": 9,
        "ytick.labelsize": 9,
        "legend.fontsize": 8,
        "savefig.dpi": 300,
    })


def style_axes(axis: plt.Axes, grid_axis: str = "both") -> None:
    axis.set_axisbelow(True)
    axis.grid(True, axis=grid_axis, color="#b8b8b8", linewidth=0.75, alpha=0.55)
    axis.spines[["top", "right"]].set_visible(False)
    axis.tick_params(direction="out", length=3.5, width=0.8)


def save(fig: plt.Figure, folder: str, name: str) -> None:
    target = OUTPUT / folder
    target.mkdir(parents=True, exist_ok=True)
    fig.savefig(target / f"{name}.png", bbox_inches="tight", facecolor="white")
    plt.close(fig)


def require_algorithms(data: pd.DataFrame, expected: list[str], context: str) -> None:
    observed = set(data["algorithm"].astype(str))
    if observed != set(expected):
        raise ValueError(
            f"{context} 算法集合不一致：缺少 {sorted(set(expected) - observed)}，"
            f"多出 {sorted(observed - set(expected))}")


def line_figure(data: pd.DataFrame, *, x: str, y: str, title: str,
                xlabel: str, ylabel: str, folder: str, name: str,
                order: list[str]) -> None:
    fig, axis = plt.subplots(figsize=(7.2, 5.2))
    for algorithm in order:
        block = data[data.algorithm == algorithm].sort_values(x)
        if block.empty:
            raise ValueError(f"{name} 缺少算法 {algorithm} 的绘图数据")
        axis.plot(
            block[x], block[y], color=COLORS[algorithm],
            marker=MARKERS[algorithm], markersize=4.8,
            markevery=max(1, len(block) // 10), markeredgecolor="white",
            markeredgewidth=0.35, label=algorithm,
        )
    axis.set(title=title, xlabel=xlabel, ylabel=ylabel)
    style_axes(axis)
    axis.legend(ncol=2, frameon=True, framealpha=0.9)
    fig.tight_layout()
    save(fig, folder, name)


def horizontal_bar(data: pd.DataFrame, *, value: str, error: str | None,
                   title: str, xlabel: str, folder: str, name: str,
                   lower_better: bool = False) -> None:
    data = data.sort_values(value, ascending=lower_better).reset_index(drop=True)
    fig, axis = plt.subplots(figsize=(7.2, 5.2))
    y = np.arange(len(data))
    errors = data[error] if error and error in data else None
    axis.barh(
        y, data[value], xerr=errors, capsize=3,
        color=[COLORS[name] for name in data.algorithm],
        edgecolor="white", linewidth=0.7,
    )
    axis.set_yticks(y, [DISPLAY_LABELS.get(name, name) for name in data.algorithm])
    axis.invert_yaxis()
    axis.set(title=title, xlabel=xlabel)
    style_axes(axis, "x")
    fig.tight_layout()
    save(fig, folder, name)


def figure6_main_comparison() -> None:
    folder = "01_图6_主场景覆盖性能"
    specs = [
        ("图6a_实际绘图统计数据.csv", "total_coverage_mean", "total_coverage_std",
         "Overall coverage", "Overall coverage (%)", "图6a_总体覆盖率"),
        ("图6b_实际绘图统计数据.csv", "special_coverage_mean", "special_coverage_std",
         "Priority-area coverage", "Priority-area coverage (%)", "图6b_重点区域覆盖率"),
    ]
    for csv_name, value, error, title, xlabel, name in specs:
        data = pd.read_csv(DATA / folder / csv_name)
        require_algorithms(data, ORDER, csv_name)
        horizontal_bar(
            data, value=value, error=error, title=title, xlabel=xlabel,
            folder=folder, name=name,
        )


def figure8_convergence() -> None:
    data_folder = "02_图7_十算法等FEs覆盖率收敛"
    output_folder = "03_图8_十算法等FEs覆盖率收敛"
    data = pd.read_csv(DATA / data_folder / "图7_实际绘图均值数据.csv")
    require_algorithms(data, PLOT_ORDER, "图8")
    for scenario, title, name in [
        ("gamma_0dB_M20", "SINR=0 dB, M=20", "图8a_SINR0dB_M20_总体覆盖率收敛"),
        ("gamma_3dB_M20", "SINR=3 dB, M=20", "图8b_SINR3dB_M20_总体覆盖率收敛"),
    ]:
        line_figure(
            data[data.scenario == scenario], x="actual_fes",
            y="mean_total_coverage", title=title,
            xlabel="Objective-function evaluations (FEs)",
            ylabel="Overall coverage (%)", folder=output_folder, name=name,
            order=PLOT_ORDER,
        )


def ablation_figure(data_folder: str, csv_name: str, figure_no: str,
                    output_folder: str, title: str) -> None:
    data = pd.read_csv(DATA / data_folder / csv_name)
    require_algorithms(data, ABLATION_ORDER, figure_no)
    for metric, ylabel, suffix in [
        ("total_coverage", "Overall coverage (%)", "总体覆盖率"),
        ("best_fitness", "Composite objective (lower is better)", "综合目标"),
    ]:
        line_figure(
            data[data.metric == metric], x="checkpoint_seconds", y="mean_value",
            title=title, xlabel="Time (s)", ylabel=ylabel, folder=output_folder,
            name=f"{figure_no}_{suffix}", order=ABLATION_ORDER,
        )


def clipped_coverage_errors(means: np.ndarray, stds: np.ndarray) -> np.ndarray:
    return np.vstack([np.minimum(stds, means), np.minimum(stds, 100.0 - means)])


def figure11_six_scenario_robustness() -> None:
    data_folder = "05_图10_六场景覆盖性能"
    output_folder = "06_图11_六场景覆盖性能"
    data = pd.read_csv(DATA / data_folder / "图10_实际绘图数据.csv")
    require_algorithms(data, PLOT_ORDER, "图11")
    panels = [
        (0, "total_coverage", "Overall coverage (%)", "图11a_0dB_总体覆盖率"),
        (3, "total_coverage", "Overall coverage (%)", "图11b_3dB_总体覆盖率"),
        (0, "special_coverage", "Priority-area coverage (%)", "图11c_0dB_重点区域覆盖率"),
        (3, "special_coverage", "Priority-area coverage (%)", "图11d_3dB_重点区域覆盖率"),
    ]
    for threshold, metric, ylabel, name in panels:
        subset = data[(data.sinr_threshold_db == threshold) & (data.metric == metric)]
        fig, axis = plt.subplots(figsize=(7.2, 5.2))
        lower_bounds = []
        for algorithm in PLOT_ORDER:
            line = subset[subset.algorithm == algorithm].sort_values("num_uavs")
            means = line["mean"].to_numpy(float)
            stds = line["std"].to_numpy(float)
            lower_bounds.extend((means - stds).tolist())
            axis.errorbar(
                line["num_uavs"], means,
                yerr=clipped_coverage_errors(means, stds),
                color=COLORS[algorithm], marker=MARKERS[algorithm],
                markersize=5.5, capsize=3, label=algorithm,
            )
        axis.set(
            title=f"SINR={threshold} dB", xlabel="Number of UAV-BSs (M)",
            ylabel=ylabel, xticks=[10, 15, 20],
        )
        axis.set_ylim(max(0, 5 * np.floor(min(lower_bounds) / 5)), 100)
        style_axes(axis)
        axis.legend(ncol=2, frameon=True, framealpha=0.9)
        fig.tight_layout()
        save(fig, output_folder, name)


def figure12_rankings() -> None:
    data_folder = "06_图11_十算法六场景平均排名"
    output_folder = "07_图12_十算法六场景平均排名"
    data = pd.read_csv(DATA / data_folder / "图11_实际绘图排名数据.csv")
    require_algorithms(data, ORDER, "图12")
    specs = {
        "total_coverage": ("Overall-coverage mean rank", "图12a_总体覆盖率平均排名"),
        "special_coverage": ("Priority-area mean rank", "图12b_重点区域平均排名"),
        "best_fitness": ("Composite-objective mean rank", "图12c_综合目标平均排名"),
    }
    for metric, (title, name) in specs.items():
        horizontal_bar(
            data[data.metric == metric], value="mean", error="std", title=title,
            xlabel="Mean rank (lower is better)", folder=output_folder, name=name,
            lower_better=True,
        )


def figure13_layouts() -> None:
    data_root = DATA / "07_图12_固定布局分布"
    output_folder = "08_图13_固定布局分布"
    labels = {
        "uniform": "Uniform users", "hotspot": "Hotspot users",
        "edge_priority": "Edge-priority users",
    }
    manifest = pd.read_csv(data_root / "manifest.csv")
    if len(manifest) != 6 or set(manifest.layout_type) != set(labels):
        raise ValueError("图13必须包含3类、每类2个固定布局")
    for index, row in manifest.reset_index(drop=True).iterrows():
        bundle = np.load(data_root / f"{row.layout_id}.npz")
        demand = bundle["user_weights"]
        priority = bundle["special_area"]
        fig, axis = plt.subplots(figsize=(6.2, 5.2), constrained_layout=True)
        image = axis.imshow(demand, cmap="YlGnBu", origin="lower", vmin=0,
                            vmax=max(4.0, float(manifest.demand_max.max())))
        axis.contour(priority, levels=[0.5], colors=["#D62728"], linewidths=1.5,
                     origin="lower")
        axis.set_title(f"{row.layout_id} | {labels[row.layout_type]}")
        axis.set_xticks([])
        axis.set_yticks([])
        fig.colorbar(image, ax=axis, shrink=0.82, label="Normalized user demand")
        save(fig, output_folder, f"图13{chr(ord('a') + index)}_{row.layout_id}")


def figure14_cross_layout() -> None:
    data_folder = "08_图13_跨布局鲁棒性"
    output_folder = "09_图14_跨布局鲁棒性"
    summary = pd.read_csv(DATA / data_folder / "图13a_按布局类型统计.csv")
    ranks = pd.read_csv(DATA / data_folder / "图13b_跨布局排名.csv")
    worst = pd.read_csv(DATA / data_folder / "图13c_最差布局统计.csv")
    require_algorithms(summary, ORDER, "图14a")
    require_algorithms(ranks, ORDER, "图14b")
    require_algorithms(worst, ORDER, "图14c")
    for layout, title, suffix in [
        ("uniform", "Uniform layout", "uniform"),
        ("hotspot", "Hotspot layout", "hotspot"),
        ("edge_priority", "Edge-priority layout", "edge_priority"),
    ]:
        horizontal_bar(
            summary[summary.layout_type == layout], value="total_coverage_mean",
            error="total_coverage_std", title=title, xlabel="Overall coverage (%)",
            folder=output_folder, name=f"图14a_{suffix}_总体覆盖率",
        )
    horizontal_bar(
        ranks[ranks.metric == "best_fitness"], value="mean_rank", error="std_rank",
        title="Cross-layout composite-objective mean rank",
        xlabel="Mean rank (lower is better)", folder=output_folder,
        name="图14b_跨布局平均排名", lower_better=True,
    )
    horizontal_bar(
        worst, value="worst_layout_total_coverage", error=None,
        title="Worst fixed-layout coverage",
        xlabel="Minimum layout-level mean coverage (%)", folder=output_folder,
        name="图14c_最差固定布局覆盖率",
    )


def main() -> None:
    configure_style()
    figure6_main_comparison()
    figure8_convergence()
    ablation_figure(
        "03_图8_3dB_10UAV_10秒等时间消融", "图8_实际绘图均值数据.csv",
        "图9", "04_图9_3dB_10UAV_10秒等时间消融",
        "SINR=3 dB, M=10, 10 s",
    )
    ablation_figure(
        "04_图9_3dB_10UAV_30秒等时间消融", "图9_实际绘图均值数据.csv",
        "图10", "05_图10_3dB_10UAV_30秒等时间消融",
        "SINR=3 dB, M=10, 30 s",
    )
    figure11_six_scenario_robustness()
    figure12_rankings()
    figure13_layouts()
    figure14_cross_layout()
    print(f"PNG figures written to: {OUTPUT}")


if __name__ == "__main__":
    main()
