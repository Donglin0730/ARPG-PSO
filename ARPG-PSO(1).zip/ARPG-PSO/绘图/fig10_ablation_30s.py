from 绘图.generate_paper_figures import ablation_figure, configure_style

if __name__ == "__main__":
    configure_style()
    ablation_figure(
        "04_图9_3dB_10UAV_30秒等时间消融",
        "图9_实际绘图均值数据.csv",
        "图10",
        "05_图10_3dB_10UAV_30秒等时间消融",
        "SINR=3 dB, M=10, 30 s",
    )
