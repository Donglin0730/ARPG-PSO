from 绘图.generate_paper_figures import ablation_figure, configure_style

if __name__ == "__main__":
    configure_style()
    ablation_figure(
        "03_图8_3dB_10UAV_10秒等时间消融",
        "图8_实际绘图均值数据.csv",
        "图9",
        "04_图9_3dB_10UAV_10秒等时间消融",
        "SINR=3 dB, M=10, 10 s",
    )
