from 绘图.generate_paper_figures import (
    configure_style,
    figure11_six_scenario_robustness,
)

if __name__ == "__main__":
    configure_style()
    figure11_six_scenario_robustness()
