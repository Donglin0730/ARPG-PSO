# -*- coding: utf-8 -*-
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

import model
from exp_config import DISPLAY_LABELS, PAPER_ALGORITHMS
from exp_utils import configure_scenario


def representative_rows(results: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for algorithm in PAPER_ALGORITHMS:
        block = results[results.algorithm == algorithm].copy()
        if block.empty:
            raise ValueError(f"主场景结果缺少算法：{algorithm}")
        median = float(block.total_coverage.median())
        row = block.loc[(block.total_coverage - median).abs().idxmin()]
        rows.append(row)
    return pd.DataFrame(rows)


def position_path(scenario_root: Path, row: pd.Series) -> Path:
    return (
        scenario_root / "best_positions" / str(row.algorithm)
        / f"run_{int(row.run):02d}_seed_{int(row.seed)}.npy"
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--scenario-root",
        type=Path,
        default=ROOT / "实验结果" / "01_等评价次数多场景" / "gamma_0dB_M20",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "生成图表" / "02_图7_最终部署分布" / "图7_十算法最终部署分布.png",
    )
    args = parser.parse_args()

    results_path = args.scenario_root / "results.csv"
    results = pd.read_csv(results_path)
    selected = representative_rows(results)
    missing = [position_path(args.scenario_root, row) for _, row in selected.iterrows()
               if not position_path(args.scenario_root, row).exists()]
    if missing:
        raise FileNotFoundError(
            "缺少最优三维坐标，无法重绘图7。请用当前 run_equal_fe.py 重新运行"
            f"主场景；首个缺失文件：{missing[0]}"
        )

    parameters = configure_scenario(20, 0.0, 6000)
    area = model.load_special_area().astype(bool)
    fig, axes = plt.subplots(2, 5, figsize=(15, 6.2), constrained_layout=True)
    priority_cmap = ListedColormap([(1, 1, 1, 0), (0.98, 0.72, 0.42, 0.58)])
    uncovered_cmap = ListedColormap([(1, 1, 1, 0), (0.86, 0.18, 0.18, 0.72)])

    for axis, (_, row) in zip(axes.flat, selected.iterrows()):
        positions = np.load(position_path(args.scenario_root, row))
        stations = [model.init_base_station(p[2], (p[0], p[1])) for p in positions]
        sinr = np.zeros((parameters["size"], parameters["size"]), dtype=float)
        covered = np.zeros_like(sinr, dtype=int)
        model.update_coverage(sinr, covered, stations, parameters["size"])
        axis.imshow(area.astype(int), origin="lower", cmap=priority_cmap, vmin=0, vmax=1)
        axis.imshow((covered == 0).astype(int), origin="lower", cmap=uncovered_cmap,
                    vmin=0, vmax=1)
        for station in stations:
            axis.add_patch(plt.Circle(
                (station["x"], station["y"]), station["radius_grid"],
                fill=False, linestyle="--", linewidth=0.55, color="#66A9D8",
                alpha=0.62,
            ))
        axis.scatter(positions[:, 0], positions[:, 1], marker="^", s=19,
                     facecolor="black", edgecolor="white", linewidth=0.3, zorder=3)
        label = DISPLAY_LABELS.get(str(row.algorithm), str(row.algorithm))
        axis.set_title(f"{label}\nCoverage={row.total_coverage:.2f}%", fontsize=9)
        axis.set_xlim(0, parameters["size"])
        axis.set_ylim(0, parameters["size"])
        axis.set_xticks([])
        axis.set_yticks([])

    args.output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(args.output, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(f"Figure written to: {args.output}")


if __name__ == "__main__":
    main()
