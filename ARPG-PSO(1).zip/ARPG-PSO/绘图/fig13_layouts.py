from 绘图.generate_paper_figures import configure_style, figure13_layouts

if __name__ == "__main__":
    configure_style()
    figure13_layouts()
