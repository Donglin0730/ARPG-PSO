# -*- coding: utf-8 -*-
import os
import numpy as np

# ----------------------------------------------------------------------------
# 1. 参数设定
# ----------------------------------------------------------------------------
def canshu():
    """返回整个优化问题所需的全部参数。"""
    p = {
        # --- 区域 / 网格 ---
        'size': 50,                 # n, 区域被划分为 size x size 个网格
        'cell_size': 40.0,          # 每个网格代表的物理边长(米), 用于把网格坐标换算成米

        # --- 无人机基站 ---
        'num_base_stations': 20,    # M, 无人机基站数量
        'h_min': 100.0,             # 最小飞行高度(米)
        'h_max': 500.0,             # 最大飞行高度(米)
        'theta_deg': 45.0,          # 信号俯仰角(度), 覆盖半径 r = h*tan(theta)

        # --- 传播 / 信道 ---
        'Pt_dbm': 30.0,             # 发射功率(dBm), 30dBm = 1W
        'freq': 2.0e9,              # 载波频率(Hz), 2GHz
        'light_speed': 3.0e8,       # 光速(m/s)
        # 总接收噪声功率：-174 dBm/Hz + 10log10(1 MHz) + 4 dB NF = -110 dBm
        'N0_dbm': -110.0,
        'gamma_th_db': 0.0,         # SINR 有效覆盖门限(dB)
        'sinr_floor_db': -50.0,     # 未覆盖点的 SINR 下限(dB), 保证统计量有限

        # --- PSO 算法 ---
        'num_particles': 20,        # 种群规模 N
        'max_iterations': 100,

        # --- 目标权重 ---
        'w1': 0.5,                  # 整体未覆盖率最重要
        'w2': 0.3,                  # 其次重点区域波动度
        'w3': 0.2,                  # 最后常规区域波动度
    }
    return p


# 模块级标准化统计量 (z-score), 由 calibrate_normalization 一次性标定后固定不变
_NORM = {'mu': np.array([0.0, 0.0, 0.0]),
         'sigma': np.array([1.0, 1.0, 1.0]),
         'eps': 1e-8,
         'ready': False}

# 缓存全局参数, 便于各函数取用 (在 canshu() 之外保持一份)
_P = canshu()

_USER_WEIGHTS = None


def configure_user_weights(user_weights=None):
    """Set a non-negative spatial user-demand map (normalised to mean one).

    ``None`` restores the legacy assumption of one equally important user at
    every grid cell.  The map affects the coverage ratio and the weighted SINR
    dispersion terms, but not the radio propagation field itself.
    """
    global _USER_WEIGHTS
    if user_weights is None:
        _USER_WEIGHTS = None
        return
    weights = np.asarray(user_weights, dtype=float)
    expected = (_P['size'], _P['size'])
    if weights.shape != expected:
        raise ValueError(f'user_weights shape {weights.shape} != {expected}')
    if not np.isfinite(weights).all() or np.any(weights < 0):
        raise ValueError('user_weights must be finite and non-negative')
    mean = float(weights.mean())
    if mean <= 0:
        raise ValueError('user_weights must contain positive demand')
    _USER_WEIGHTS = weights / mean


def _demand_weights(size):
    if _USER_WEIGHTS is None:
        return np.ones((size, size), dtype=float)
    if _USER_WEIGHTS.shape != (size, size):
        raise RuntimeError('configured user-demand map does not match scenario size')
    return _USER_WEIGHTS


def _weighted_std(values, weights):
    values = np.asarray(values, dtype=float)
    weights = np.asarray(weights, dtype=float)
    total = float(weights.sum())
    if total <= 0:
        return 0.0
    mean = float(np.sum(weights * values) / total)
    return float(np.sqrt(np.sum(weights * np.square(values - mean)) / total))


# ----------------------------------------------------------------------------
# 2. 基站对象
# ----------------------------------------------------------------------------
def init_base_station(height, position):
    """
    创建一个无人机基站描述字典。
    height   : 飞行高度(米)
    position : (x, y) 网格坐标
    覆盖半径(网格单位) = h*tan(theta) / cell_size
    """
    theta = np.deg2rad(_P['theta_deg'])
    radius_m = height * np.tan(theta)            # 物理覆盖半径(米)
    radius_grid = radius_m / _P['cell_size']      # 换算为网格单位
    return {
        'x': float(position[0]),
        'y': float(position[1]),
        'h': float(height),
        'radius_m': float(radius_m),
        'radius_grid': float(radius_grid),
    }


# ----------------------------------------------------------------------------
# 3. 覆盖 / SINR 计算 (向量化)
# ----------------------------------------------------------------------------
def _compute_sinr_field(base_stations, size):
    """
    给定一组基站, 计算整个网格上每个点的 SINR(dB) 与覆盖标志。
    返回:
        sinr_db     : (size, size) 每个网格点的 SINR(dB)
        covered     : (size, size) bool, 是否被有效覆盖 (在波束内且 SINR>=门限)
    """
    cell = _P['cell_size']
    f = _P['freq']
    c = _P['light_speed']
    Pt = _P['Pt_dbm']
    N0_dbm = _P['N0_dbm']
    gamma_th = _P['gamma_th_db']
    floor_db = _P['sinr_floor_db']

    M = len(base_stations)

    # 网格点中心坐标(网格单位): cell (i=行=y, j=列=x) 中心为 (j+0.5, i+0.5)
    jj, ii = np.meshgrid(np.arange(size) + 0.5, np.arange(size) + 0.5)  # (size,size)

    # 各基站坐标 / 高度 / 半径
    bx = np.array([b['x'] for b in base_stations]).reshape(M, 1, 1)
    by = np.array([b['y'] for b in base_stations]).reshape(M, 1, 1)
    bh = np.array([b['h'] for b in base_stations]).reshape(M, 1, 1)
    br = np.array([b['radius_grid'] for b in base_stations]).reshape(M, 1, 1)

    gx = jj.reshape(1, size, size)
    gy = ii.reshape(1, size, size)

    # 二维水平距离(网格单位) -> 判断是否落在波束足印内
    d2d_grid = np.sqrt((bx - gx) ** 2 + (by - gy) ** 2)        # (M,size,size)
    in_footprint = d2d_grid <= br                             # (M,size,size) bool

    # 三维距离(米): 水平距离换算成米, 再叠加高度
    d3d_m = np.sqrt((d2d_grid * cell) ** 2 + bh ** 2)
    d3d_m = np.maximum(d3d_m, 1.0)                            # 防止 log(0)

    # LOS 自由空间路径损耗(dB):  L = 20log10(d) + 20log10(f) + 20log10(4*pi/c)
    L = 20 * np.log10(d3d_m) + 20 * np.log10(f) + 20 * np.log10(4 * np.pi / c)
    Pr_dbm = Pt - L                                          # 接收功率(dBm) (M,size,size)
    Pr_lin = 10 ** (Pr_dbm / 10.0)                           # 转线性(mW)

    # 仅波束足印内的功率参与服务/干扰计算, 足印外置 0
    Pr_lin_fp = np.where(in_footprint, Pr_lin, 0.0)

    # 服务 UAV: 足印内接收功率最大者
    serving = Pr_lin_fp.max(axis=0)                          # (size,size)
    total_lin = Pr_lin_fp.sum(axis=0)                        # 所有足印内基站功率之和
    interference = total_lin - serving                       # 同频干扰 = 其余基站之和

    N0_lin = 10 ** (N0_dbm / 10.0)

    # SINR = 服务信号 / (干扰 + 噪声)
    sinr_lin = serving / (interference + N0_lin)
    with np.errstate(divide='ignore'):
        sinr_db = 10 * np.log10(np.where(sinr_lin > 0, sinr_lin, 1e-30))

    coverable = serving > 0                                   # 至少被一个基站波束覆盖
    sinr_db = np.where(coverable, sinr_db, floor_db)          # 未覆盖点的质量置下限
    sinr_db = np.maximum(sinr_db, floor_db)

    covered = coverable & (sinr_db >= gamma_th)               # 有效覆盖判定
    return sinr_db, covered


def update_coverage(grid, coverage_grid, base_stations, size):
    """
    用给定基站集合更新:
        grid          : (size,size) float, 存放每个网格点的 SINR(dB) (作为通信质量 q_ij)
        coverage_grid : (size,size) int,   1=有效覆盖, 0=未覆盖
    原地修改, 同时返回 (grid, coverage_grid)。
    """
    sinr_db, covered = _compute_sinr_field(base_stations, size)
    grid[:, :] = sinr_db
    coverage_grid[:, :] = covered.astype(int)
    return grid, coverage_grid


# ----------------------------------------------------------------------------
# 4. 三个目标项 (原始值)
# ----------------------------------------------------------------------------
def _raw_objectives(size, grid, coverage_grid, special_area):
    """
    计算三个原始目标项:
        f1 : 整体未覆盖率 = (N - 覆盖点数) / N
        f2 : 重点区域 SINR 波动度 (标准差)
        f3 : 常规区域 SINR 波动度 (标准差)
    """

    # f1: 整体未覆盖率
    demand = _demand_weights(size)
    f1 = float(np.sum(demand * (1 - coverage_grid)) / np.sum(demand))

    # q_ij = SINR(dB)
    q = grid

    special_mask = special_area.astype(bool)
    normal_mask = ~special_mask

    # f2: 重点区域波动度 (标准差)
    if special_mask.sum() > 0:
        f2 = _weighted_std(q[special_mask], demand[special_mask])
    else:
        f2 = 0.0

    # f3: 常规区域波动度 (标准差)
    if normal_mask.sum() > 0:
        f3 = _weighted_std(q[normal_mask], demand[normal_mask])
    else:
        f3 = 0.0

    return np.array([f1, f2, f3], dtype=float)


# ----------------------------------------------------------------------------
# 5. z-score 标准化标定
# ----------------------------------------------------------------------------
def calibrate_normalization(size, special_area, num_samples=60, seed=0):
    """
    预实验: 随机生成若干部署方案, 统计三个目标项的均值/标准差,
    作为 z-score 标准化的 mu, sigma, 整个优化过程保持不变。
    """
    rng = np.random.default_rng(seed)
    M = _P['num_base_stations']
    samples = np.zeros((num_samples, 3))
    grid = np.zeros((size, size), dtype=float)
    cov = np.zeros((size, size), dtype=int)
    for s in range(num_samples):
        bss = []
        for _ in range(M):
            x = rng.uniform(0, size)
            y = rng.uniform(0, size)
            h = rng.uniform(_P['h_min'], _P['h_max'])
            bss.append(init_base_station(h, (x, y)))
        update_coverage(grid, cov, bss, size)
        samples[s] = _raw_objectives(size, grid, cov, special_area)

    mu = samples.mean(axis=0)
    sigma = samples.std(axis=0)
    sigma[sigma < 1e-8] = 1e-8
    _NORM['mu'] = mu
    _NORM['sigma'] = sigma
    _NORM['ready'] = True
    return mu, sigma


# ----------------------------------------------------------------------------
# 6. 加权目标函数 F
# ----------------------------------------------------------------------------
def objective_function(size, grid, coverage_grid, special_area):
    """
    计算加权标准化目标值 F (越小越好):
        f_hat_k = (f_k - mu_k) / (sigma_k + eps)
        F = w1*f_hat_1 + w2*f_hat_2 + w3*f_hat_3
    """
    raw = _raw_objectives(size, grid, coverage_grid, special_area)
    if _NORM['ready']:
        f_hat = (raw - _NORM['mu']) / (_NORM['sigma'] + _NORM['eps'])
    else:
        # 未标定时退化为原始加权 (一般不会走到这里)
        f_hat = raw
    F = _P['w1'] * f_hat[0] + _P['w2'] * f_hat[1] + _P['w3'] * f_hat[2]
    return float(F)


# ----------------------------------------------------------------------------
# 7. 覆盖率与均匀性统计 (用于结果汇总)
# ----------------------------------------------------------------------------
def calculate_coverage_and_uniformity(size, grid, coverage_grid, special_area):
    """
    返回:
        total_coverage   : 整体覆盖率 (%)
        special_coverage : 重点区域覆盖率 (%)
        general_coverage : 常规区域覆盖率 (%)
        std_special      : 重点区域 SINR 标准差 (波动度)
        std_general      : 常规区域 SINR 标准差 (波动度)
    """
    special_mask = special_area.astype(bool)
    normal_mask = ~special_mask
    demand = _demand_weights(size)
    total_coverage = 100.0 * float(np.sum(demand * coverage_grid)) / float(demand.sum())

    if special_mask.sum() > 0:
        special_demand = demand[special_mask]
        special_coverage = (100.0 * float(np.sum(
            special_demand * coverage_grid[special_mask]))
            / float(special_demand.sum()))
        std_special = _weighted_std(grid[special_mask], special_demand)
    else:
        special_coverage = 0.0
        std_special = 0.0

    if normal_mask.sum() > 0:
        general_demand = demand[normal_mask]
        general_coverage = (100.0 * float(np.sum(
            general_demand * coverage_grid[normal_mask]))
            / float(general_demand.sum()))
        std_general = _weighted_std(grid[normal_mask], general_demand)
    else:
        general_coverage = 0.0
        std_general = 0.0

    return total_coverage, special_coverage, general_coverage, std_special, std_general


# ----------------------------------------------------------------------------
# 8. 重点区域(特殊区域)的保存 / 载入
# ----------------------------------------------------------------------------
_SPECIAL_AREA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  'special_area.npy')


def save_special_area(special_area):
    np.save(_SPECIAL_AREA_FILE, special_area.astype(np.int8))


def load_special_area():
    """载入已保存的重点区域掩码; 若不存在则即时生成并保存。"""
    if os.path.exists(_SPECIAL_AREA_FILE):
        return np.load(_SPECIAL_AREA_FILE).astype(int)
    from tetromino_generator import generate_special_area
    area = generate_special_area(size=_P['size'])
    save_special_area(area)
    return area
