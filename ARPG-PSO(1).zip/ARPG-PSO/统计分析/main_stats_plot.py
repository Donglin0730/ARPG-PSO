# -*- coding: utf-8 -*-
from __future__ import annotations

import os

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from exp_config import DISPLAY_LABELS, PAPER_ALGORITHMS


SOURCE = os.path.join("实验结果", "01_等评价次数多场景", "gamma_0dB_M20")
OUTPUT = os.path.join("实验结果", "05_主场景图表")
ALGORITHMS = list(PAPER_ALGORITHMS)
DISPLAY = DISPLAY_LABELS
COLORS = {
    "PSO": "#457B9D", "MPSO": "#D55E00", "CLPSO": "#8AB17D",
    "DMS-PSO": "#F4A261", "SPSO": "#E9C46A", "MPSORL": "#7B6D8D",
    "AFMPSO": "#CC79A7", "AMSEPSO": "#56B4E9", "FHPSO": "#E69F00",
    "ARPG-PSO-v3.1-MAPPO": "#7A0177",
}


def load_and_validate() -> tuple[pd.DataFrame, pd.DataFrame]:
    final = pd.read_csv(os.path.join(SOURCE, "results.csv"))
    history = pd.read_csv(os.path.join(SOURCE, "fe_histories.csv"))
    final = final[final.algorithm.isin(ALGORITHMS)].copy()
    history = history[history.algorithm.isin(ALGORITHMS)].copy()
    if len(final) != 200 or set(final.algorithm) != set(ALGORITHMS):
        raise ValueError("Expected 10 algorithms x 20 runs in the main scenario")
    counts = final.groupby("algorithm").size()
    if not counts.eq(20).all() or final.duplicated(["algorithm", "seed"]).any():
        raise ValueError("Incomplete or duplicate algorithm/seed cells")
    if not final.actual_fes.eq(6000).all():
        raise ValueError("Main comparison is not exactly equal-FE")
    return final, history


def convergence_table(history: pd.DataFrame) -> pd.DataFrame:
    """First FE reaching 95% of each run's observed coverage improvement."""
    rows = []
    for (algorithm, seed), run in history.groupby(["algorithm", "seed"]):
        run = run.sort_values("actual_fes")
        values = run.total_coverage.to_numpy()
        target = values[0] + 0.95 * (values[-1] - values[0])
        reached = run.loc[run.total_coverage >= target, "actual_fes"]
        rows.append({
            "algorithm": algorithm,
            "seed": int(seed),
            "convergence_fes_95pct_gain": int(reached.iloc[0]) if len(reached) else 6000,
        })
    return pd.DataFrame(rows)


def summary_table(final: pd.DataFrame, convergence: pd.DataFrame) -> pd.DataFrame:
    merged = final.merge(convergence, on=["algorithm", "seed"], validate="one_to_one")
    metrics = ["total_coverage", "special_coverage", "elapsed_seconds",
               "convergence_fes_95pct_gain"]
    summary = merged.groupby("algorithm")[metrics].agg(["mean", "std", "count"])
    summary.columns = [f"{metric}_{stat}" for metric, stat in summary.columns]
    return summary.reindex(ALGORITHMS).reset_index(), merged


def add_panel(axis, summary, metric, title, xlabel, higher_better):
    order = summary.sort_values(f"{metric}_mean", ascending=not higher_better)
    y = np.arange(len(order))
    means = order[f"{metric}_mean"].to_numpy()
    errors = order[f"{metric}_std"].to_numpy()
    labels = [DISPLAY.get(item, item) for item in order.algorithm]
    axis.barh(y, means, xerr=errors,
              color=[COLORS[item] for item in order.algorithm],
              edgecolor="#222222", linewidth=0.8, capsize=4, alpha=0.95)
    axis.set_yticks(y, labels)
    axis.invert_yaxis()
    axis.set_title(title, loc="left", fontweight="bold")
    axis.set_xlabel(xlabel)
    axis.grid(axis="x", linestyle=":", alpha=0.35)
    axis.set_axisbelow(True)
    axis.spines[["top", "right"]].set_visible(False)
    span = max(means.max() - means.min(), errors.max(), 1.0)
    for yi, mean, std in zip(y, means, errors):
        axis.text(mean + std + 0.025 * span, yi, f"{mean:.2f}±{std:.2f}",
                  va="center", fontsize=8)


def plot(summary: pd.DataFrame) -> None:
    fig, axes = plt.subplots(2, 2, figsize=(18, 10.5))
    panels = [
        ("total_coverage", "(a) Overall coverage", "Overall coverage (%)", True),
        ("special_coverage", "(b) Priority-area coverage", "Priority-area coverage (%)", True),
        ("elapsed_seconds", "(c) Runtime", "Runtime (s)", False),
        ("convergence_fes_95pct_gain", "(d) Convergence speed",
         "FEs to 95% of observed coverage gain", False),
    ]
    for axis, args in zip(axes.flat, panels):
        add_panel(axis, summary, *args)
    fig.suptitle("Ten-algorithm comparison: SINR=0 dB, M=20, 6000 FEs, 20 paired seeds",
                 fontsize=16, fontweight="bold")
    fig.tight_layout(rect=(0, 0, 1, 0.96), h_pad=3.0, w_pad=4.0)
    fig.savefig(os.path.join(OUTPUT, "arpg_pso_ten_algorithm_comparison.png"),
                dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def main() -> None:
    os.makedirs(OUTPUT, exist_ok=True)
    final, history = load_and_validate()
    convergence = convergence_table(history)
    summary, merged = summary_table(final, convergence)
    merged.to_csv(os.path.join(OUTPUT, "main_scenario_all_results.csv"),
                  index=False, encoding="utf-8-sig")
    summary.to_csv(os.path.join(OUTPUT, "main_scenario_summary.csv"),
                   index=False, encoding="utf-8-sig")
    convergence.to_csv(os.path.join(OUTPUT, "convergence_fes.csv"),
                       index=False, encoding="utf-8-sig")
    plot(summary)
    print("Validated 200 strict equal-FE runs; generated ten-algorithm main figure.")


if __name__ == "__main__":
    main()
