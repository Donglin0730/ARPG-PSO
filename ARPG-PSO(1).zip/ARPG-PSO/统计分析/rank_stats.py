# -*- coding: utf-8 -*-
from __future__ import annotations

import os

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import rankdata

from exp_config import (
    DISPLAY_LABELS,
    PAPER_ALGORITHMS,
    RUNS_PER_SCENARIO,
    SINR_THRESHOLDS_DB,
    TARGET,
    UAV_COUNTS,
)


SOURCE = os.path.join("实验结果", "01_等评价次数多场景")
OUTPUT = os.path.join("实验结果", "04_十算法综合统计")
ALGORITHMS = list(PAPER_ALGORITHMS)
DISPLAY = DISPLAY_LABELS
COLORS = {
    "PSO": "#457B9D", "MPSO": "#D55E00",
    "CLPSO": "#8AB17D", "DMS-PSO": "#F4A261",
    "SPSO": "#E9C46A", "MPSORL": "#7B6D8D",
    "AFMPSO": "#CC79A7", "AMSEPSO": "#56B4E9",
    "FHPSO": "#E69F00", TARGET: "#7A0177",
}
SCENARIOS = [
    f"gamma_{threshold}dB_M{uavs}"
    for threshold in SINR_THRESHOLDS_DB for uavs in UAV_COUNTS
]


def load_data() -> tuple[pd.DataFrame, pd.DataFrame]:
    finals, histories = [], []
    for scenario in SCENARIOS:
        folder = os.path.join(SOURCE, scenario)
        finals.append(pd.read_csv(os.path.join(folder, "results.csv")))
        histories.append(pd.read_csv(os.path.join(folder, "fe_histories.csv")))
    final = pd.concat(finals, ignore_index=True)
    history = pd.concat(histories, ignore_index=True)
    final = final[final.algorithm.isin(ALGORITHMS)].copy()
    history = history[history.algorithm.isin(ALGORITHMS)].copy()
    expected = len(SCENARIOS) * len(ALGORITHMS) * RUNS_PER_SCENARIO
    if len(final) != expected:
        raise ValueError(f"Expected {expected} final rows, found {len(final)}")
    counts = final.groupby(["scenario", "algorithm"]).size()
    if not counts.eq(20).all() or final.duplicated(
            ["scenario", "algorithm", "seed"]).any():
        raise ValueError("Incomplete or duplicate final-result cells")
    if (final.actual_fes > final.fe_budget).any():
        raise ValueError("An algorithm exceeded the FE budget")
    return final, history


def calculate_ranks(final: pd.DataFrame) -> pd.DataFrame:
    rows = []
    directions = {
        "total_coverage": False,
        "special_coverage": False,
        "best_fitness": True,
    }
    for metric, ascending in directions.items():
        for (scenario, seed), block in final.groupby(["scenario", "seed"]):
            block = block.set_index("algorithm").reindex(ALGORITHMS)
            values = block[metric].to_numpy()
            ranks = rankdata(values if ascending else -values, method="average")
            rows.extend({
                "metric": metric, "scenario": scenario, "seed": seed,
                "algorithm": algorithm, "rank": float(rank),
            } for algorithm, rank in zip(ALGORITHMS, ranks))
    return pd.DataFrame(rows)


def plot_rankings(ranks: pd.DataFrame, output: str) -> None:
    metrics = [
        ("total_coverage", "Overall coverage"),
        ("special_coverage", "Priority-area coverage"),
        ("best_fitness", "Composite objective"),
    ]
    fig, axes = plt.subplots(1, 3, figsize=(15.5, 5.8), sharey=True)
    y = np.arange(len(ALGORITHMS))
    labels = [DISPLAY.get(item, item) for item in ALGORITHMS]
    for axis, (metric, title) in zip(axes, metrics):
        block = ranks[ranks.metric == metric].groupby("algorithm")["rank"]
        means = block.mean().reindex(ALGORITHMS)
        errors = block.std().reindex(ALGORITHMS)
        axis.barh(y, means, xerr=errors, color=[COLORS[x] for x in ALGORITHMS],
                  capsize=3, alpha=0.92)
        axis.set_title(title, fontweight="bold")
        axis.set_xlabel("Mean rank (lower is better)")
        axis.set_xlim(0, 11)
        axis.grid(axis="x", linestyle=":", alpha=0.4)
        axis.spines[["top", "right"]].set_visible(False)
    axes[0].set_yticks(y, labels)
    axes[0].invert_yaxis()
    fig.suptitle("Ten-algorithm ranks across 6 equal-FE scenarios × 20 seeds",
                 fontsize=15, fontweight="bold")
    fig.tight_layout(rect=(0, 0, 1, 0.94))
    fig.savefig(output, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def step_resample(block: pd.DataFrame, grid: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    values = []
    for _, run in block.groupby("seed"):
        run = run.sort_values("actual_fes")
        indexes = np.searchsorted(run.actual_fes.to_numpy(), grid,
                                  side="right") - 1
        sampled = np.full(len(grid), np.nan)
        valid = indexes >= 0
        sampled[valid] = run.total_coverage.to_numpy()[indexes[valid]]
        values.append(sampled)
    matrix = np.asarray(values)
    return np.nanmean(matrix, axis=0), np.nanstd(matrix, axis=0, ddof=1)


def plot_convergence(history: pd.DataFrame, output: str) -> None:
    scenarios = ["gamma_0dB_M20", "gamma_3dB_M20"]
    grid = np.arange(200, 6001, 100)
    fig, axes = plt.subplots(1, 2, figsize=(14, 5.8), sharex=True)
    for axis, scenario in zip(axes, scenarios):
        block = history[history.scenario == scenario]
        for algorithm in ALGORITHMS:
            mean, std = step_resample(block[block.algorithm == algorithm], grid)
            axis.plot(grid, mean, color=COLORS[algorithm], linewidth=2,
                      label=DISPLAY.get(algorithm, algorithm))
            axis.fill_between(grid, mean - std, mean + std,
                              color=COLORS[algorithm], alpha=0.09)
        threshold = int(block.gamma_th_db.iloc[0])
        uavs = int(block.num_uavs.iloc[0])
        axis.set_title(f"SINR={threshold} dB, M={uavs}", fontweight="bold")
        axis.set_xlabel("Objective-function evaluations (FEs)")
        axis.set_ylabel("Overall coverage (%)")
        axis.grid(linestyle=":", alpha=0.4)
        axis.spines[["top", "right"]].set_visible(False)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=5, frameon=False)
    fig.suptitle("Ten-algorithm convergence under the same 6000-FE budget",
                 fontsize=15, fontweight="bold")
    fig.tight_layout(rect=(0, 0.12, 1, 0.94))
    fig.savefig(output, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def main() -> None:
    os.makedirs(OUTPUT, exist_ok=True)
    final, history = load_data()
    ranks = calculate_ranks(final)
    rank_summary = ranks.groupby(["metric", "algorithm"])["rank"].agg(
        ["mean", "std", "count"]).reset_index()
    final.to_csv(os.path.join(OUTPUT, "all_results.csv"), index=False,
                 encoding="utf-8-sig")
    ranks.to_csv(os.path.join(OUTPUT, "all_block_ranks.csv"), index=False,
                 encoding="utf-8-sig")
    rank_summary.to_csv(os.path.join(OUTPUT, "average_rankings.csv"), index=False,
                        encoding="utf-8-sig")
    plot_rankings(ranks, os.path.join(OUTPUT, "ten_algorithm_rankings.png"))
    plot_convergence(
        history, os.path.join(OUTPUT, "ten_algorithm_convergence.png"))
    print(f"Validated {len(final)} results; generated standard ten-algorithm views.")


if __name__ == "__main__":
    main()
