# -*- coding: utf-8 -*-
from __future__ import annotations

import argparse
import os

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

from exp_config import (
    ABLATION_ORDER,
    LEGACY_ABLATION_ALIASES,
)


ROOT = os.path.join("实验结果", "02_等时间实验")
ORDER = list(ABLATION_ORDER)
ABLATIONS = ORDER[:-1]
COLORS = ["#7A8B99", "#4C78A8", "#F28E2B", "#8E258D"]
DISPLAY_LABELS = {
    "Base-only": "Base-only",
    "Frozen-Actor": "Frozen-Actor",
    "No-selection": "No-selection",
    "Full-v3.1": "ARPG-PSO",
}
METRICS = [
    ("total_coverage", "greater", "Overall coverage (%)"),
    ("special_coverage", "greater", "Priority-area coverage (%)"),
    ("best_fitness", "less", "Composite objective (lower is better)"),
]


def holm(p_values):
    values = np.asarray(p_values, dtype=float)
    order = np.argsort(values)
    adjusted = np.empty_like(values)
    running = 0.0
    for rank, index in enumerate(order):
        running = max(running, (len(values) - rank) * values[index])
        adjusted[index] = min(running, 1.0)
    return adjusted


def validate(data, history, expected_runs=20):
    if set(data.algorithm) != set(ORDER):
        raise ValueError(f"Unexpected groups: {set(data.algorithm)}")
    counts = data.groupby("algorithm").size().reindex(ORDER)
    if not (counts == expected_runs).all():
        raise ValueError(f"Incomplete final results:\n{counts}")
    if data.duplicated(["algorithm", "run", "seed"]).any():
        raise ValueError("Duplicate final result rows")
    if not data.time_cap_ok.astype(str).str.lower().eq("true").all():
        raise ValueError("At least one run exceeded the hard time cap")
    if (data.elapsed_seconds > data.time_budget_seconds + 1e-9).any():
        raise ValueError("Recorded elapsed time exceeds the budget")
    per_run_history = history.groupby(["algorithm", "run"]).size()
    checkpoints_per_run = int(per_run_history.iloc[0])
    if not (per_run_history == checkpoints_per_run).all():
        raise ValueError("Inconsistent checkpoint counts across runs")
    history_counts = history.groupby("algorithm").size().reindex(ORDER)
    expected_history = expected_runs * checkpoints_per_run
    if not (history_counts == expected_history).all():
        raise ValueError(f"Incomplete checkpoint histories:\n{history_counts}")
    if history.duplicated(["algorithm", "run", "checkpoint_seconds"]).any():
        raise ValueError("Duplicate checkpoint rows")


def summarize(data):
    metrics = [
        "total_coverage", "special_coverage", "general_coverage",
        "best_fitness", "elapsed_seconds", "unused_seconds",
        "budget_utilization", "iterations_completed", "actual_fes",
        "milliseconds_per_fe",
    ]
    summary = data.groupby("algorithm")[metrics].agg(["mean", "std", "median"])
    summary.columns = [f"{metric}_{stat}" for metric, stat in summary.columns]
    summary = summary.reset_index()
    summary["order"] = summary.algorithm.map({v: i for i, v in enumerate(ORDER)})
    summary = summary.sort_values("order").drop(columns="order")
    summary["algorithm"] = summary["algorithm"].map(DISPLAY_LABELS)
    return summary


def paired_tests(data):
    full = data[data.algorithm == "Full-v3.1"].set_index("run")
    rows = []
    for metric, alternative, _ in METRICS:
        family = []
        for group in ABLATIONS:
            other = data[data.algorithm == group].set_index("run")
            runs = full.index.intersection(other.index)
            x = full.loc[runs, metric].to_numpy(dtype=float)
            y = other.loc[runs, metric].to_numpy(dtype=float)
            raw_difference = x - y
            favourable = raw_difference if alternative == "greater" else -raw_difference
            try:
                p_one = stats.wilcoxon(
                    x, y, alternative=alternative, zero_method="wilcox").pvalue
                p_two = stats.wilcoxon(
                    x, y, alternative="two-sided", zero_method="wilcox").pvalue
            except ValueError:
                p_one = p_two = 1.0
            family.append({
                "metric": metric,
                "target": "Full-v3.1",
                "compared_with": group,
                "pairs": len(runs),
                "alternative": alternative,
                "full_mean": float(np.mean(x)),
                "ablation_mean": float(np.mean(y)),
                "raw_full_minus_ablation_mean": float(np.mean(raw_difference)),
                "effect_positive_favours_full_mean": float(np.mean(favourable)),
                "effect_positive_favours_full_median": float(np.median(favourable)),
                "full_wins": int(np.sum(favourable > 0)),
                "ties": int(np.sum(favourable == 0)),
                "full_losses": int(np.sum(favourable < 0)),
                "p_one_sided": float(p_one),
                "p_two_sided": float(p_two),
            })
        adjusted_one = holm([row["p_one_sided"] for row in family])
        adjusted_two = holm([row["p_two_sided"] for row in family])
        for row, p_one, p_two in zip(family, adjusted_one, adjusted_two):
            row["p_one_sided_holm"] = float(p_one)
            row["superior_holm_0.05"] = bool(p_one < 0.05)
            row["p_two_sided_holm"] = float(p_two)
            rows.append(row)
    result = pd.DataFrame(rows)
    result["target"] = result["target"].map(DISPLAY_LABELS)
    result["compared_with"] = result["compared_with"].map(DISPLAY_LABELS)
    return result


def comparison_figure(data, output, figure_title):
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.8))
    positions = np.arange(1, len(ORDER) + 1)
    for axis, (metric, _, title) in zip(axes, METRICS):
        values = [
            data.loc[data.algorithm == group, metric].to_numpy(dtype=float)
            for group in ORDER
        ]
        boxes = axis.boxplot(
            values, positions=positions, widths=0.58, patch_artist=True,
            showmeans=True,
            meanprops={"marker": "D", "markerfacecolor": "white",
                       "markeredgecolor": "black", "markersize": 4},
            medianprops={"color": "black", "linewidth": 1.2})
        for patch, color in zip(boxes["boxes"], COLORS):
            patch.set_facecolor(color)
            patch.set_alpha(0.82)
        axis.set_title(title)
        axis.set_xticks(positions)
        axis.set_xticklabels(
            [DISPLAY_LABELS[group] for group in ORDER], rotation=18,
            ha="right")
        axis.grid(axis="y", alpha=0.25)
    if figure_title:
        fig.suptitle(figure_title)
    fig.tight_layout()
    fig.savefig(output, dpi=300, bbox_inches="tight")
    plt.close(fig)


def convergence_figure(history, output, figure_title):
    fig, axes = plt.subplots(1, 2, figsize=(13.5, 5.0))
    plot_metrics = [
        ("total_coverage", "Overall coverage (%)"),
        ("best_fitness", "Composite objective (lower is better)"),
    ]
    for axis, (metric, ylabel) in zip(axes, plot_metrics):
        for group, color in zip(ORDER, COLORS):
            block = history[history.algorithm == group]
            grouped = block.groupby("checkpoint_seconds")[metric]
            mean = grouped.mean()
            std = grouped.std(ddof=1)
            x = mean.index.to_numpy(dtype=float)
            y = mean.to_numpy(dtype=float)
            s = std.to_numpy(dtype=float)
            axis.plot(
                x, y, label=DISPLAY_LABELS[group], color=color,
                linewidth=2.1)
            axis.fill_between(x, y - s, y + s, color=color, alpha=0.13)
        axis.set_xlabel("Optimization time (s)")
        axis.set_ylabel(ylabel)
        axis.grid(alpha=0.25)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=4, frameon=False)
    if figure_title:
        fig.suptitle(figure_title)
    fig.tight_layout(rect=[0, 0.10, 1, 1])
    fig.savefig(output, dpi=300, bbox_inches="tight")
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default=os.path.join(ROOT, "raw_results.csv"))
    parser.add_argument("--history", default=os.path.join(ROOT, "time_histories.csv"))
    parser.add_argument("--output", default=ROOT)
    parser.add_argument(
        "--figure-title",
        default="ARPG-PSO equal-time ablation convergence")
    parser.add_argument("--no-figure-title", action="store_true")
    args = parser.parse_args()
    data = pd.read_csv(args.input)
    history = pd.read_csv(args.history)
    data["algorithm"] = data["algorithm"].replace(LEGACY_ABLATION_ALIASES)
    history["algorithm"] = history["algorithm"].replace(LEGACY_ABLATION_ALIASES)
    figure_title = "" if args.no_figure_title else args.figure_title
    validate(data, history)
    summary = summarize(data)
    tests = paired_tests(data)
    summary.to_csv(os.path.join(args.output, "formal_summary.csv"), index=False,
                   encoding="utf-8-sig")
    tests.to_csv(os.path.join(args.output, "paired_tests_holm.csv"), index=False,
                 encoding="utf-8-sig")
    comparison_figure(
        data, os.path.join(args.output, "equal_time_ablation_comparison.png"),
        figure_title)
    convergence_figure(
        history, os.path.join(args.output, "equal_time_ablation_convergence.png"),
        figure_title)
    print(summary[[
        "algorithm", "total_coverage_mean", "total_coverage_std",
        "special_coverage_mean", "best_fitness_mean", "actual_fes_mean",
        "elapsed_seconds_mean",
    ]].to_string(index=False))
    print("\nPrimary paired tests:\n", tests[
        tests.metric == "total_coverage"].to_string(index=False))


if __name__ == "__main__":
    main()
