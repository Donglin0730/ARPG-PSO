# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

from exp_config import (
    DISPLAY_LABELS,
    FE_BUDGET,
    PAPER_ALGORITHMS,
    RUNS_PER_SCENARIO,
    SINR_THRESHOLDS_DB,
    TARGET,
    UAV_COUNTS,
)


ROOT = os.path.join("实验结果", "01_等评价次数多场景")
ALGORITHMS = list(PAPER_ALGORITHMS)
SCENARIOS = [
    f"gamma_{threshold}dB_M{uavs}"
    for threshold in SINR_THRESHOLDS_DB
    for uavs in UAV_COUNTS
]
COLORS = {
    "PSO": "#457B9D", "MPSO": "#D55E00",
    "CLPSO": "#8AB17D", "DMS-PSO": "#F4A261",
    "SPSO": "#E9C46A", "MPSORL": "#7B6D8D",
    "AFMPSO": "#CC79A7", "AMSEPSO": "#56B4E9",
    "FHPSO": "#E69F00", TARGET: "#7A0177",
}
EXPECTED_RUNS = RUNS_PER_SCENARIO


def holm(p_values: list[float]) -> np.ndarray:
    values = np.asarray(p_values, dtype=float)
    order = np.argsort(values)
    adjusted = np.empty_like(values)
    running = 0.0
    for rank, index in enumerate(order):
        running = max(running, (len(values) - rank) * values[index])
        adjusted[index] = min(running, 1.0)
    return adjusted


def load_and_validate(root: str = ROOT) -> pd.DataFrame:
    frames = []
    for scenario in SCENARIOS:
        path = os.path.join(root, scenario, "results.csv")
        if not os.path.exists(path):
            raise FileNotFoundError(path)
        frames.append(pd.read_csv(path))
    data = pd.concat(frames, ignore_index=True, sort=False)
    data = data[data.algorithm.isin(ALGORITHMS)].copy()
    expected = len(SCENARIOS) * len(ALGORITHMS) * EXPECTED_RUNS
    if len(data) != expected:
        raise ValueError(f"Expected {expected} rows, found {len(data)}")
    keys = ["scenario", "algorithm", "seed"]
    if data.duplicated(keys).any():
        raise ValueError("Duplicate scenario/algorithm/seed rows detected")
    counts = data.groupby(["scenario", "algorithm"]).size()
    if len(counts) != len(SCENARIOS) * len(ALGORITHMS):
        raise ValueError("One or more scenario/algorithm cells are absent")
    if not (counts == EXPECTED_RUNS).all():
        raise ValueError(f"Incomplete cells:\n{counts[counts != EXPECTED_RUNS]}")
    if set(data.algorithm) != set(ALGORITHMS):
        raise ValueError(f"Unexpected algorithms: {sorted(set(data.algorithm))}")
    if (data.fe_budget != FE_BUDGET).any():
        raise ValueError("Inconsistent declared FE budgets")
    if (data.actual_fes > data.fe_budget).any():
        raise ValueError("An optimiser exceeded the FE budget")
    target = data[data.algorithm == TARGET]
    audit = target.rollout_audit_ok.astype(str).str.lower()
    if not audit.eq("true").all():
        raise ValueError("ARPG-PSO rollout audit failed")
    return data


def make_summary(data: pd.DataFrame) -> pd.DataFrame:
    metrics = [
        "actual_fes", "unused_fes", "best_fitness", "total_coverage",
        "special_coverage", "general_coverage", "elapsed_seconds",
    ]
    rows = []
    group_keys = ["scenario", "gamma_th_db", "num_uavs", "algorithm"]
    for keys, block in data.groupby(group_keys, sort=False):
        row = dict(zip(group_keys, keys))
        row["runs"] = len(block)
        for metric in metrics:
            row[f"{metric}_mean"] = float(block[metric].mean())
            row[f"{metric}_std"] = float(block[metric].std(ddof=1))
            row[f"{metric}_median"] = float(block[metric].median())
        rows.append(row)
    return pd.DataFrame(rows)


def paired_tests(data: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for scenario in SCENARIOS:
        block = data[data.scenario == scenario]
        target = block[block.algorithm == TARGET].set_index("seed")
        for metric, alternative in (
            ("total_coverage", "greater"),
            ("special_coverage", "greater"),
            ("best_fitness", "less"),
        ):
            family = []
            for algorithm in ALGORITHMS[:-1]:
                other = block[block.algorithm == algorithm].set_index("seed")
                seeds = target.index.intersection(other.index)
                x = target.loc[seeds, metric].to_numpy()
                y = other.loc[seeds, metric].to_numpy()
                difference = x - y
                try:
                    statistic, p_value = stats.wilcoxon(
                        x, y, alternative=alternative, method="auto")
                    statistic_two, p_value_two = stats.wilcoxon(
                        x, y, alternative="two-sided", method="auto")
                except ValueError:
                    statistic = statistic_two = 0.0
                    p_value = p_value_two = 1.0
                family.append({
                    "scenario": scenario, "target": TARGET,
                    "compared_with": algorithm, "metric": metric,
                    "alternative": alternative, "n": len(seeds),
                    "statistic": statistic, "p_value": p_value,
                    "statistic_two_sided": statistic_two,
                    "p_value_two_sided": p_value_two,
                    "mean_difference": float(np.mean(difference)),
                    "median_difference": float(np.median(difference)),
                })
            adjusted = holm([row["p_value"] for row in family])
            adjusted_two = holm(
                [row["p_value_two_sided"] for row in family])
            for row, p_adj, p_two_adj in zip(family, adjusted, adjusted_two):
                row["p_value_holm"] = float(p_adj)
                row["superior_holm_0.05"] = bool(p_adj < 0.05)
                row["p_value_two_sided_holm"] = float(p_two_adj)
                row["different_holm_0.05"] = bool(p_two_adj < 0.05)
                rows.append(row)
    return pd.DataFrame(rows)


def threshold_tests(data: pd.DataFrame) -> pd.DataFrame:
    averaged = data.groupby(
        ["gamma_th_db", "algorithm", "seed"], as_index=False
    )[["total_coverage", "special_coverage", "best_fitness"]].mean()
    averaged["scenario"] = averaged.gamma_th_db.map(
        lambda value: f"gamma_{value:g}dB_average_M")
    frames = []
    for threshold in (0, 3):
        block = averaged[averaged.gamma_th_db == threshold].copy()
        # paired_tests expects one of the formal scenario identifiers.
        scenario = f"gamma_{threshold}dB_average_M"
        target = block[block.algorithm == TARGET].set_index("seed")
        rows = []
        for metric, alternative in (
            ("total_coverage", "greater"),
            ("special_coverage", "greater"),
            ("best_fitness", "less"),
        ):
            family = []
            for algorithm in ALGORITHMS[:-1]:
                other = block[block.algorithm == algorithm].set_index("seed")
                seeds = target.index.intersection(other.index)
                x = target.loc[seeds, metric].to_numpy()
                y = other.loc[seeds, metric].to_numpy()
                try:
                    statistic, p_value = stats.wilcoxon(
                        x, y, alternative=alternative, method="auto")
                except ValueError:
                    statistic, p_value = 0.0, 1.0
                family.append({
                    "scenario": scenario, "target": TARGET,
                    "compared_with": algorithm, "metric": metric,
                    "alternative": alternative, "n": len(seeds),
                    "statistic": statistic, "p_value": p_value,
                    "mean_difference": float(np.mean(x - y)),
                    "median_difference": float(np.median(x - y)),
                })
            adjusted = holm([row["p_value"] for row in family])
            for row, p_adj in zip(family, adjusted):
                row["p_value_holm"] = float(p_adj)
                row["superior_holm_0.05"] = bool(p_adj < 0.05)
                rows.append(row)
        frames.append(pd.DataFrame(rows))
    return pd.concat(frames, ignore_index=True)


def plot_grid(summary: pd.DataFrame, output: str) -> None:
    fig, axes = plt.subplots(2, 2, figsize=(14, 9), sharex=True)
    metrics = [
        ("total_coverage", "Overall coverage (%)"),
        ("special_coverage", "Priority-area coverage (%)"),
    ]
    for column, threshold in enumerate((0, 3)):
        subset = summary[summary.gamma_th_db == threshold]
        for row, (metric, ylabel) in enumerate(metrics):
            axis = axes[row, column]
            for algorithm in ALGORITHMS:
                line = subset[subset.algorithm == algorithm].sort_values(
                    "num_uavs")
                axis.errorbar(
                    line.num_uavs, line[f"{metric}_mean"],
                    yerr=line[f"{metric}_std"], marker="o", linewidth=2,
                    capsize=3, color=COLORS[algorithm],
                    label=DISPLAY_LABELS.get(algorithm, algorithm),
                )
            axis.set_title(
                f"Equal-FE robustness: SINR threshold={threshold} dB",
                fontweight="bold",
            )
            axis.set_ylabel(ylabel)
            # Coverage is physically bounded to [0, 100]. Error bars show
            # mean +/- one standard deviation and are clipped at these axes
            # limits when their statistical interval crosses a boundary.
            axis.set_ylim(0, 100)
            axis.set_xticks([10, 15, 20])
            axis.grid(True, linestyle=":", alpha=0.45)
            if row == 1:
                axis.set_xlabel("Number of UAV-BSs (M)")
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=5, frameon=False)
    fig.suptitle("Strict comparison under a 6000-FE budget", fontweight="bold")
    fig.tight_layout(rect=(0, 0.08, 1, 0.96))
    fig.savefig(output, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def write_protocol(data: pd.DataFrame) -> None:
    protocol = {
        "objective": "Ten-algorithm SINR/UAV-scale robustness comparison",
        "formal_algorithm": "ARPG-PSO",
        "implementation_version": "v3.1",
        "sinr_thresholds_db": [0, 3],
        "uav_counts": [10, 15, 20],
        "algorithms": [DISPLAY_LABELS.get(item, item) for item in ALGORITHMS],
        "runs_per_cell": EXPECTED_RUNS,
        "paired_seed_base": 70042,
        "particles": 20,
        "pso_parameters": {"inertia_weight": 0.7, "c1": 1.6, "c2": 1.8},
        "max_function_evaluations": FE_BUDGET,
        "max_observed_actual_fes": int(data.actual_fes.max()),
        "max_observed_unused_fes": int(data.unused_fes.max()),
    }
    with open(os.path.join(ROOT, "protocol.json"), "w", encoding="utf-8") as f:
        json.dump(protocol, f, ensure_ascii=False, indent=2)


def main() -> None:
    data = load_and_validate()
    summary = make_summary(data)
    tests = paired_tests(data)
    aggregate = threshold_tests(data)
    data.to_csv(os.path.join(ROOT, "all_results.csv"), index=False,
                encoding="utf-8-sig")
    summary.to_csv(os.path.join(ROOT, "scenario_summary.csv"), index=False,
                   encoding="utf-8-sig")
    tests.to_csv(os.path.join(ROOT, "wilcoxon_all_scenarios.csv"), index=False,
                 encoding="utf-8-sig")
    aggregate.to_csv(
        os.path.join(ROOT, "wilcoxon_threshold_aggregate.csv"), index=False,
        encoding="utf-8-sig",
    )
    plot_grid(
        summary,
        os.path.join(ROOT, "arpg_pso_equal_fe_robustness_vs_variants.png"),
    )
    write_protocol(data)
    print(f"Validated {len(data)} equal-FE runs across six scenarios.")
    print(f"Maximum actual FEs: {int(data.actual_fes.max())}")
    print(f"Maximum unused FEs: {int(data.unused_fes.max())}")


if __name__ == "__main__":
    main()
