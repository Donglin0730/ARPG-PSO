# -*- coding: utf-8 -*-
from __future__ import annotations

import argparse
import subprocess
import sys

from exp_config import (
    FE_BUDGET,
    PARTICLES,
    RUNS_PER_SCENARIO,
    SINR_THRESHOLDS_DB,
    UAV_COUNTS,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--runs", type=int, default=RUNS_PER_SCENARIO)
    parser.add_argument("--particles", type=int, default=PARTICLES)
    parser.add_argument(
        "--function-evaluations", "--fe-budget", dest="fe_budget",
        type=int, default=FE_BUDGET,
        help="最大函数评价次数；--fe-budget 仅为旧命令兼容名",
    )
    parser.add_argument("--seed-base", type=int, default=70042)
    parser.add_argument("--output-root", default="实验结果/01_等评价次数多场景")
    parser.add_argument("--fresh", action="store_true")
    args = parser.parse_args()

    for threshold in SINR_THRESHOLDS_DB:
        for uavs in UAV_COUNTS:
            command = [
                sys.executable,
                "-m",
                "实验代码.主场景与六场景.run_equal_fe",
                "--threshold", str(threshold), "--uavs", str(uavs),
                "--runs", str(args.runs), "--particles", str(args.particles),
                "--function-evaluations", str(args.fe_budget),
                "--seed-base", str(args.seed_base),
                "--output-root", args.output_root,
            ]
            if args.fresh:
                command.append("--fresh")
            print(f"Running SINR={threshold} dB, M={uavs}", flush=True)
            subprocess.run(command, check=True)


if __name__ == "__main__":
    main()
