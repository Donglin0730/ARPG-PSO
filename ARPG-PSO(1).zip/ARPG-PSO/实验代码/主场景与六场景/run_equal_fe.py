# -*- coding: utf-8 -*-
"""Run experiments with a fixed function-evaluation limit.

每次调用运行一个场景，并在每次完整更新后保存检查点。函数评价次数是
硬上限，结果按运行批次持续写入，实验中断后可继续执行。
"""

from __future__ import annotations

import argparse
import os
import time

import numpy as np
import pandas as pd
import torch

from 算法代码.registry import (
    ARPG_PSO_v31,
    PAPER_ALGORITHM_CLASSES,
)
from model import calibrate_normalization, load_special_area
from exp_config import (
    FE_BUDGET,
    PAPER_ALGORITHMS,
    PARTICLES,
    RUNS_PER_SCENARIO,
    TARGET,
)
from exp_utils import configure_scenario, final_metrics


ROOT = os.path.join('实验结果', '01_等评价次数多场景')
ALGORITHMS = dict(PAPER_ALGORITHM_CLASSES)

if tuple(ALGORITHMS) != PAPER_ALGORITHMS:
    raise RuntimeError('等评价次数算法列表与实验配置不一致')


def generation_cost_bound(label, particles):
    if label.startswith('ARPG-PSO-v3.'):
        return 3 * particles
    return particles


def schedule_horizon(label, particles, fe_budget):
    regular_cost = (3 * particles if label.startswith('ARPG-PSO-v3.')
                    else particles)
    return max(1, fe_budget // regular_cost)


def make_optimizer(label, p, area, particles):
    cls = ALGORITHMS[label]
    if label.startswith('ARPG-PSO-v3.'):
        return cls(p, area, num_particles=particles,
                   acceptance_mode='certified')
    return cls(p, area, num_particles=particles)


def audit_v31(optimizer, p, expected_fes):
    if not isinstance(optimizer, ARPG_PSO_v31):
        return True
    return bool(
        optimizer.evaluation_count == expected_fes
        and optimizer.mappo.sampled_action_count
        == optimizer.mappo.executed_transition_count
        * p['num_base_stations']
        and all(len(values) == 0
                for values in optimizer.mappo.rollout.values())
        and np.isfinite(optimizer.mappo.last_ratio_mean)
    )


def run_one(label, p, area, particles, fe_budget):
    optimizer = make_optimizer(label, p, area, particles)
    max_cost = generation_cost_bound(label, particles)
    horizon = schedule_horizon(label, particles, fe_budget)
    histories = []
    iteration = 0
    started = time.perf_counter()

    while optimizer.evaluation_count + max_cost <= fe_budget:
        before = optimizer.evaluation_count
        best_fitness = optimizer.update(iteration, horizon)
        used = optimizer.evaluation_count - before
        if not 0 < used <= max_cost:
            raise RuntimeError(
                f'{label}: generation used {used} FEs; bound={max_cost}')
        best_position, _ = optimizer.get_best_solution()
        total, special, general, _, _, _ = final_metrics(
            best_position, p, area)
        histories.append({
            'iteration': iteration + 1,
            'actual_fes': int(optimizer.evaluation_count),
            'best_fitness': float(best_fitness),
            'total_coverage': total,
            'special_coverage': special,
            'general_coverage': general,
        })
        iteration += 1

    best_position, best_fitness = optimizer.get_best_solution()
    total, special, general, f1, f2, f3 = final_metrics(
        best_position, p, area)
    final = {
        'fe_budget': fe_budget,
        'actual_fes': int(optimizer.evaluation_count),
        'unused_fes': int(fe_budget - optimizer.evaluation_count),
        'iterations_completed': iteration,
        'best_fitness': float(best_fitness),
        'total_coverage': total,
        'special_coverage': special,
        'general_coverage': general,
        'f1_uncov': f1,
        'f2_spec_std': f2,
        'f3_gen_std': f3,
        'elapsed_seconds': time.perf_counter() - started,
        'rollout_audit_ok': audit_v31(
            optimizer, p, optimizer.evaluation_count),
    }
    if isinstance(optimizer, ARPG_PSO_v31):
        final.update({
            'sampled_actions': optimizer.mappo.sampled_action_count,
            'executed_transitions': optimizer.mappo.executed_transition_count,
            'final_ppo_ratio': optimizer.mappo.last_ratio_mean,
            'mean_reward': float(np.mean(optimizer.history['mean_reward'])),
            'residual_success_rate': float(np.mean(
                optimizer.history['residual_success_rate'])),
        })
    else:
        final.update({
            'sampled_actions': 0, 'executed_transitions': 0,
            'final_ppo_ratio': 1.0, 'mean_reward': np.nan,
            'residual_success_rate': (
                float(np.mean(optimizer.history['residual_success_rate']))
                if label == TARGET and optimizer.history.get('residual_success_rate')
                else np.nan),
        })
    return final, histories, np.asarray(best_position, dtype=float)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--threshold', type=float, required=True)
    parser.add_argument('--uavs', type=int, required=True)
    parser.add_argument('--runs', type=int, default=RUNS_PER_SCENARIO)
    parser.add_argument('--particles', type=int, default=PARTICLES)
    parser.add_argument(
        '--function-evaluations', '--fe-budget', dest='fe_budget',
        type=int, default=FE_BUDGET,
        help='最大函数评价次数；--fe-budget 仅为旧命令兼容名',
    )
    parser.add_argument('--seed-base', type=int, default=60042)
    parser.add_argument('--output-root', default=ROOT)
    parser.add_argument('--algorithms', nargs='+', choices=list(ALGORITHMS))
    parser.add_argument('--fresh', action='store_true')
    args = parser.parse_args()

    scenario = f'gamma_{args.threshold:g}dB_M{args.uavs}'
    output = os.path.join(args.output_root, scenario)
    os.makedirs(output, exist_ok=True)
    results_path = os.path.join(output, 'results.csv')
    histories_path = os.path.join(output, 'fe_histories.csv')
    positions_root = os.path.join(output, 'best_positions')
    rows, histories = [], []
    if not args.fresh and os.path.exists(results_path):
        rows = pd.read_csv(results_path).to_dict('records')
        if os.path.exists(histories_path):
            histories = pd.read_csv(histories_path).to_dict('records')
    completed = {(str(row['algorithm']), int(row['seed'])) for row in rows}

    p = configure_scenario(args.uavs, args.threshold, args.fe_budget)
    area = load_special_area()
    mu, sigma = calibrate_normalization(
        p['size'], area, num_samples=60, seed=0)
    labels = args.algorithms or list(ALGORITHMS)
    print(f'{scenario}: budget={args.fe_budget}, runs={args.runs}, '
          f'mu={np.asarray(mu).tolist()}, sigma={np.asarray(sigma).tolist()}',
          flush=True)

    for label in labels:
        for run in range(args.runs):
            seed = args.seed_base + 100 * run
            if (label, seed) in completed:
                continue
            np.random.seed(seed)
            torch.manual_seed(seed)
            final, trajectory, best_position = run_one(
                label, p, area, args.particles, args.fe_budget)
            common = {
                'scenario': scenario, 'gamma_th_db': args.threshold,
                'num_uavs': args.uavs, 'noise_dbm': -110.0,
                'noise_density_dbm_hz': -174.0,
                'effective_bandwidth_hz': 1.0e6,
                'noise_figure_db': 4.0,
                'algorithm': label, 'run': run + 1, 'seed': seed,
                'particles': args.particles,
            }
            rows.append({**common, **final})
            histories.extend({**common, **item} for item in trajectory)
            pd.DataFrame(rows).to_csv(results_path, index=False,
                                      encoding='utf-8-sig')
            pd.DataFrame(histories).to_csv(histories_path, index=False,
                                           encoding='utf-8-sig')
            algorithm_positions = os.path.join(positions_root, label)
            os.makedirs(algorithm_positions, exist_ok=True)
            np.save(
                os.path.join(
                    algorithm_positions,
                    f'run_{run + 1:02d}_seed_{seed}.npy',
                ),
                best_position.reshape(args.uavs, 3),
            )
            print(f'{label} {run + 1:02d}/{args.runs}: '
                  f'FEs={final["actual_fes"]}/{args.fe_budget}, '
                  f'coverage={final["total_coverage"]:.3f}%, '
                  f'fitness={final["best_fitness"]:.4f}, '
                  f'time={final["elapsed_seconds"]:.2f}s, '
                  f'audit={final["rollout_audit_ok"]}', flush=True)
    print(f'COMPLETED {scenario}: {len(rows)} final rows', flush=True)


if __name__ == '__main__':
    main()
