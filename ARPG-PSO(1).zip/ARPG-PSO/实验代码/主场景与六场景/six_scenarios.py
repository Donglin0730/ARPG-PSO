from 实验代码.主场景与六场景.run_six_scenarios import main


if __name__ == "__main__":
    main()
