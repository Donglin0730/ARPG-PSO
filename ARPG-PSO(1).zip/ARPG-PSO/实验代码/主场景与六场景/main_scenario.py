import sys

from 实验代码.主场景与六场景.run_equal_fe import main


def add_default(flag: str, value: str) -> None:
    if flag not in sys.argv[1:]:
        sys.argv.extend([flag, value])


if __name__ == "__main__":
    add_default("--threshold", "0")
    add_default("--uavs", "20")
    add_default("--runs", "20")
    add_default("--particles", "20")
    add_default("--function-evaluations", "6000")
    add_default("--seed-base", "70042")
    add_default("--output-root", "实验结果/01_等评价次数多场景")
    main()
