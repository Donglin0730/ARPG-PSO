from 实验代码.跨布局实验.run_cross_layout import main


if __name__ == "__main__":
    main()
