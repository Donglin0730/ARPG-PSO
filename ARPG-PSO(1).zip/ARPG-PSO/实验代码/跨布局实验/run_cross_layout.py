# -*- coding: utf-8 -*-
"""Run experiments across fixed user-demand layouts.

实验使用三类共六个固定需求布局，每个布局运行十种算法和二十个配对随机种子。
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
from scipy.stats import friedmanchisquare, rankdata, wilcoxon

import model
from 算法代码.registry import (
    ARPG_PSO_v31,
    PAPER_ALGORITHM_CLASSES,
)
from model import calibrate_normalization, configure_user_weights
from exp_config import (
    CROSS_LAYOUT_SEEDS_PER_LAYOUT,
    FE_BUDGET,
    PAPER_ALGORITHMS,
    PARTICLES,
    TARGET,
)
from exp_utils import configure_scenario, final_metrics


ROOT = os.path.join("实验结果", "03_跨布局鲁棒性")
LAYOUT_ROOT = os.path.join(ROOT, "layouts")
DISPLAY_LABELS = {TARGET: "ARPG-PSO"}
GROUPS = [
    TARGET, "AFMPSO", "AMSEPSO", "FHPSO", "MPSO",
    "MPSORL", "DMS-PSO", "PSO", "SPSO", "CLPSO",
]
if set(GROUPS) != set(PAPER_ALGORITHMS):
    raise RuntimeError("跨布局算法列表与实验配置不一致")
COLORS = [
    "#A984D1", "#D98BC3", "#76C9D4", "#E06666", "#F6B26B",
    "#A6A6A6", "#B58A7A", "#6FA8DC", "#D5CF6A", "#93C47D",
]
LAYOUT_SPECS = [
    ("uniform_01", "uniform", 101), ("uniform_02", "uniform", 102),
    ("hotspot_01", "hotspot", 201), ("hotspot_02", "hotspot", 202),
    ("edge_01", "edge_priority", 301), ("edge_02", "edge_priority", 302),
]


def _digest(*arrays):
    value = hashlib.sha256()
    for array in arrays:
        value.update(np.ascontiguousarray(array).tobytes())
    return value.hexdigest()


def _gaussian(size, row, col, sigma):
    yy, xx = np.mgrid[0:size, 0:size]
    return np.exp(-((yy - row) ** 2 + (xx - col) ** 2) / (2.0 * sigma ** 2))


def _largest_exact(values, ratio=0.30):
    count = int(round(values.size * ratio))
    mask = np.zeros(values.size, dtype=np.int8)
    order = np.argsort(values.ravel(), kind="stable")
    mask[order[-count:]] = 1
    return mask.reshape(values.shape)


def build_layout(layout_id, layout_type, seed, size=50):
    rng = np.random.default_rng(seed)
    if layout_type == "uniform":
        demand = np.ones((size, size), dtype=float)
        # Two spatially distinct, but equal-area, priority-zone arrangements.
        centers = ([(13, 13), (37, 37)] if seed % 2
                   else [(13, 37), (37, 13)])
        score = sum(_gaussian(size, r, c, 8.5) for r, c in centers)
        score += 1e-6 * rng.random((size, size))
    elif layout_type == "hotspot":
        centers = ([(25, 25)] if seed % 2
                   else [(13, 14), (34, 16), (27, 38)])
        sigmas = ([6.0] if len(centers) == 1 else [5.0, 6.0, 5.5])
        score = sum(_gaussian(size, r, c, s)
                    for (r, c), s in zip(centers, sigmas))
        demand = 0.20 + 4.0 * score
    else:
        centers = ([(7, 12), (7, 38), (20, 6)] if seed % 2
                   else [(42, 11), (42, 38), (28, 44)])
        score = sum(_gaussian(size, r, c, 5.5) for r, c in centers)
        # The edge class is an explicit edge-demand/priority test; it does not
        # claim a building-shadow channel model that the simulator lacks.
        demand = 0.25 + 3.5 * score
    demand = demand / demand.mean()
    priority = _largest_exact(score, ratio=0.30)
    return demand.astype(np.float64), priority.astype(np.int8)


def create_layouts():
    os.makedirs(LAYOUT_ROOT, exist_ok=True)
    rows = []
    for layout_id, layout_type, seed in LAYOUT_SPECS:
        demand, priority = build_layout(layout_id, layout_type, seed)
        path = os.path.join(LAYOUT_ROOT, f"{layout_id}.npz")
        np.savez_compressed(path, user_weights=demand, special_area=priority)
        rows.append({
            "layout_id": layout_id, "layout_type": layout_type,
            "layout_seed": seed, "path": path.replace("\\", "/"),
            "priority_cells": int(priority.sum()),
            "priority_ratio": float(priority.mean()),
            "demand_min": float(demand.min()), "demand_max": float(demand.max()),
            "demand_cv": float(demand.std() / demand.mean()),
            "sha256": _digest(demand, priority),
        })
    frame = pd.DataFrame(rows)
    frame.to_csv(os.path.join(LAYOUT_ROOT, "manifest.csv"), index=False,
                 encoding="utf-8-sig")
    plot_layouts(frame)
    return frame


def load_manifest():
    path = os.path.join(LAYOUT_ROOT, "manifest.csv")
    return pd.read_csv(path) if os.path.exists(path) else create_layouts()


def load_layout(row):
    bundle = np.load(str(row["path"]).replace("/", os.sep))
    demand = bundle["user_weights"]
    priority = bundle["special_area"]
    if _digest(demand, priority) != str(row["sha256"]):
        raise RuntimeError(f"layout checksum mismatch: {row['layout_id']}")
    return demand, priority


def plot_layouts(manifest):
    labels = {"uniform": "Uniform users", "hotspot": "Hotspot users",
              "edge_priority": "Edge-priority users"}
    for _, row in manifest.iterrows():
        demand, priority = load_layout(row)
        fig, axis = plt.subplots(figsize=(6.2, 5.2), constrained_layout=True)
        image = axis.imshow(demand, cmap="YlGnBu", origin="lower", vmin=0,
                            vmax=max(4.0, float(manifest.demand_max.max())))
        axis.contour(priority, levels=[0.5], colors=["#D62728"], linewidths=1.5,
                     origin="lower")
        axis.set_title(f"{row.layout_id} | {labels[row.layout_type]}",
                       fontsize=11, fontweight="bold")
        axis.set_xticks([]); axis.set_yticks([])
        fig.colorbar(image, ax=axis, shrink=0.82, label="Normalized user demand")
        fig.savefig(os.path.join(ROOT, f"layout_{row.layout_id}.png"), dpi=260,
                    bbox_inches="tight")
        plt.close(fig)


def make_optimizer(label, p, area, particles):
    if label == TARGET:
        return ARPG_PSO_v31(
            p, area, num_particles=particles, rollout_length=5,
            actor_residual_scale=0.30, acceptance_mode="certified",
            learning_mode="mappo")
    return PAPER_ALGORITHM_CLASSES[label](
        p, area, num_particles=particles
    )


def update_cost_upper_bound(label, particles):
    if label == TARGET:
        return 3 * particles
    return particles


def schedule_length(label, particles, budget):
    regular = (3 * particles
               if label == TARGET else particles)
    return max(1, budget // regular)


def consume_remainder(optimizer, budget):
    """Use a partial final population sweep without exceeding the FE cap."""
    index = 0
    while optimizer.evaluation_count < budget:
        particle = index % optimizer.num_particles
        candidate = optimizer.positions[particle]
        value = float(optimizer.evaluate_particle(candidate))
        if value < optimizer.pbest_fitness[particle]:
            optimizer.pbest_fitness[particle] = value
            optimizer.pbest_positions[particle] = candidate.copy()
        if value < optimizer.gbest_fitness:
            optimizer.gbest_fitness = value
            optimizer.gbest_position = candidate.copy()
        index += 1


def convergence_fe(values, fes, tolerance=0.01):
    values, fes = np.asarray(values), np.asarray(fes)
    gain = max(float(values[0] - values[-1]), 0.0)
    if gain <= 1e-12:
        return int(fes[0])
    hits = np.flatnonzero(values <= values[-1] + tolerance * gain)
    return int(fes[hits[0]]) if hits.size else int(fes[-1])


def run_one(task):
    torch.set_num_threads(1)
    p = configure_scenario(task["uavs"], task["threshold_db"], task["budget"])
    p.update({"learning_rate": 3e-4, "ppo_epochs": 4})
    row = task["layout"]
    demand, area = load_layout(row)
    configure_user_weights(demand)
    calibrate_normalization(p["size"], area, num_samples=60,
                            seed=1000 + int(row["layout_seed"]))
    seed = int(task["seed"])
    np.random.seed(seed); torch.manual_seed(seed)
    optimizer = make_optimizer(task["algorithm"], p, area, task["particles"])
    max_cost = update_cost_upper_bound(task["algorithm"], task["particles"])
    horizon = schedule_length(task["algorithm"], task["particles"], task["budget"])
    values, fes = [], []
    started = time.perf_counter()
    iteration = 0
    while optimizer.evaluation_count + max_cost <= task["budget"]:
        value = optimizer.update(iteration, horizon)
        values.append(float(value)); fes.append(int(optimizer.evaluation_count))
        iteration += 1
    if optimizer.evaluation_count < task["budget"]:
        if task["algorithm"] == TARGET:
            raise RuntimeError("v3.1 budget should be divisible by its update cost")
        consume_remainder(optimizer, task["budget"])
        values.append(float(optimizer.gbest_fitness))
        fes.append(int(optimizer.evaluation_count))
    elapsed = time.perf_counter() - started
    best, fitness = optimizer.get_best_solution()
    total, special, general, f1, f2, f3 = final_metrics(best, p, area)
    audit = optimizer.evaluation_count == task["budget"]
    if task["algorithm"] == TARGET:
        audit = bool(
            audit
            and optimizer.mappo.sampled_action_count
            == optimizer.mappo.executed_transition_count * p["num_base_stations"]
            and optimizer.mappo.training_update_count == int(np.ceil(iteration / 5))
            and all(not block for block in optimizer.mappo.rollout.values()))
    common = {
        "algorithm": task["algorithm"], "layout_id": row["layout_id"],
        "layout_type": row["layout_type"], "layout_seed": int(row["layout_seed"]),
        "run": int(task["run"]), "seed": seed, "particles": task["particles"],
        "fe_budget": task["budget"], "uavs": task["uavs"],
        "threshold_db": task["threshold_db"],
    }
    result = {**common, "best_fitness": float(fitness),
              "total_coverage": total, "special_coverage": special,
              "general_coverage": general, "f1_uncov": f1,
              "f2_spec_std": f2, "f3_gen_std": f3,
              "elapsed_seconds": elapsed, "actual_fes": optimizer.evaluation_count,
              "iterations": iteration, "convergence_fes": convergence_fe(values, fes),
              "audit_ok": bool(audit)}
    history = [{**common, "iteration": i + 1, "function_evaluations": fe,
                "best_fitness": value}
               for i, (value, fe) in enumerate(zip(values, fes))]
    return result, history


def holm(values):
    values = np.asarray(values, dtype=float)
    order = np.argsort(values)
    adjusted = np.empty_like(values)
    running = 0.0
    for rank, index in enumerate(order):
        running = max(running, min(1.0, (len(values) - rank) * values[index]))
        adjusted[index] = running
    return adjusted


def all_true(values):
    """兼容布尔列和从 CSV 读取后的 True/False 字符串。"""
    return values.astype(str).str.strip().str.lower().eq("true").all()


def analyse(data, runs, budget):
    keys = ["algorithm", "layout_id", "seed"]
    expected = len(GROUPS) * len(LAYOUT_SPECS) * runs
    counts = data.groupby(["algorithm", "layout_id"]).size()
    complete = bool(
        len(data) == expected and not data.duplicated(keys).any()
        and set(data.algorithm) == set(GROUPS) and counts.eq(runs).all()
        and data.actual_fes.eq(budget).all() and all_true(data.audit_ok))
    audit = {"complete": complete, "expected_rows": expected,
             "observed_rows": len(data), "all_exact_6000_fes": bool(data.actual_fes.eq(budget).all()),
             "all_internal_audits_pass": bool(all_true(data.audit_ok))}
    with open(os.path.join(ROOT, "completeness_audit.json"), "w", encoding="utf-8") as stream:
        json.dump(audit, stream, indent=2, ensure_ascii=False)
    if not complete:
        return False

    metrics = ["total_coverage", "special_coverage", "best_fitness",
               "elapsed_seconds", "convergence_fes"]
    summary = data.groupby(["algorithm", "layout_type"])[metrics].agg(["mean", "std"])
    summary.columns = ["_".join(value) for value in summary.columns]
    summary.reset_index().to_csv(os.path.join(ROOT, "summary_by_layout_type.csv"),
                                 index=False, encoding="utf-8-sig")
    overall_summary = data.groupby("algorithm")[metrics].agg(["mean", "std"]).reindex(GROUPS)
    overall_summary.columns = ["_".join(value) for value in overall_summary.columns]
    overall_summary.reset_index().to_csv(os.path.join(ROOT, "overall_summary.csv"),
                                         index=False, encoding="utf-8-sig")
    by_layout = data.groupby(["algorithm", "layout_id"])[metrics].mean().reset_index()
    by_layout.to_csv(os.path.join(ROOT, "mean_by_fixed_layout.csv"), index=False,
                     encoding="utf-8-sig")

    rank_rows = []
    for metric, ascending in [("best_fitness", True), ("total_coverage", False),
                              ("special_coverage", False)]:
        for (layout, seed), block in data.groupby(["layout_id", "seed"]):
            ranks = rankdata(block[metric], method="average")
            if not ascending:
                ranks = rankdata(-block[metric], method="average")
            rank_rows.extend({"metric": metric, "layout_id": layout, "seed": seed,
                              "algorithm": algorithm, "rank": float(rank)}
                             for algorithm, rank in zip(block.algorithm, ranks))
    ranks = pd.DataFrame(rank_rows)
    ranks.groupby(["metric", "algorithm"]).agg(
        mean_rank=("rank", "mean"), std_rank=("rank", "std"),
        blocks=("rank", "size")).reset_index().to_csv(
            os.path.join(ROOT, "cross_layout_average_ranks.csv"), index=False,
            encoding="utf-8-sig")

    worst_rows = []
    for algorithm, block in by_layout.groupby("algorithm"):
        total_row = block.loc[block.total_coverage.idxmin()]
        special_row = block.loc[block.special_coverage.idxmin()]
        fitness_row = block.loc[block.best_fitness.idxmax()]
        worst_rows.append({
            "algorithm": algorithm,
            "worst_total_layout_id": total_row.layout_id,
            "worst_layout_total_coverage": total_row.total_coverage,
            "worst_special_layout_id": special_row.layout_id,
            "worst_layout_special_coverage": special_row.special_coverage,
            "worst_fitness_layout_id": fitness_row.layout_id,
            "worst_layout_fitness": fitness_row.best_fitness,
        })
    worst = pd.DataFrame(worst_rows).set_index("algorithm").reindex(GROUPS).reset_index()
    worst.to_csv(os.path.join(ROOT, "worst_layout_performance.csv"), index=False,
                 encoding="utf-8-sig")

    blocks = data.pivot_table(index=["layout_id", "seed"], columns="algorithm",
                              values="best_fitness").dropna()
    statistic, p_value = friedmanchisquare(*[blocks[label] for label in GROUPS])
    pd.DataFrame([{"metric": "best_fitness", "blocks": len(blocks),
                   "friedman_chi2": statistic, "p_value": p_value}]).to_csv(
        os.path.join(ROOT, "friedman_test.csv"), index=False, encoding="utf-8-sig")

    tests = []
    for metric, alternative in [("total_coverage", "greater"),
                                ("special_coverage", "greater"),
                                ("best_fitness", "less")]:
        pivot = data.pivot_table(index=["layout_id", "seed"], columns="algorithm",
                                 values=metric).dropna()
        group = []
        for label in GROUPS[1:]:
            x, y = pivot[TARGET].to_numpy(), pivot[label].to_numpy()
            try:
                stat, pval = wilcoxon(x, y, alternative=alternative)
            except ValueError:
                stat, pval = 0.0, 1.0
            favourable = x > y if alternative == "greater" else x < y
            group.append({"metric": metric, "target": TARGET,
                          "compared_with": label, "pairs": len(x),
                          "wilcoxon_statistic": stat, "p_one_sided": pval,
                          "wins": int(favourable.sum()), "ties": int((x == y).sum()),
                          "losses": int((~favourable & (x != y)).sum())})
        adjusted = holm([row["p_one_sided"] for row in group])
        for row, value in zip(group, adjusted):
            row["p_holm"] = value
            row["significant_holm_0.05"] = bool(value < 0.05)
        tests.extend(group)
    pd.DataFrame(tests).to_csv(os.path.join(ROOT, "paired_tests_holm.csv"),
                               index=False, encoding="utf-8-sig")
    plot_results(data, ranks, worst)
    write_report(data, ranks, worst, statistic, p_value, runs)
    return True


def plot_results(data, ranks, worst):
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False
    type_order = ["uniform", "hotspot", "edge_priority"]
    display_groups = [DISPLAY_LABELS.get(label, label) for label in GROUPS]
    for layout_type in type_order:
        block = data[data.layout_type == layout_type].groupby("algorithm")
        values = block.total_coverage.mean().reindex(GROUPS).sort_values(ascending=False)
        errors = block.total_coverage.std().reindex(values.index)
        fig, axis = plt.subplots(figsize=(7.2, 5.2), constrained_layout=True)
        axis.barh(np.arange(len(values)), values, xerr=errors, capsize=2,
                  color=[COLORS[GROUPS.index(label)] for label in values.index])
        axis.set_yticks(np.arange(len(values)),
                        [DISPLAY_LABELS.get(label, label) for label in values.index])
        axis.set_title(f"Overall coverage | {layout_type.replace('_', ' ')}",
                       fontweight="bold")
        axis.set_xlabel("Demand-weighted coverage (%)")
        axis.grid(axis="x", alpha=0.35)
        axis.spines[["top", "right"]].set_visible(False)
        fig.savefig(os.path.join(ROOT, f"coverage_{layout_type}.png"), dpi=260,
                    bbox_inches="tight")
        plt.close(fig)

    fitness_rank = (ranks[ranks.metric == "best_fitness"]
                    .groupby("algorithm")["rank"].mean().reindex(GROUPS)
                    .sort_values(ascending=True))
    for values, title, xlabel, filename, invert_x in [
        (fitness_rank, "Cross-layout mean rank", "Fitness rank (lower is better)",
         "cross_layout_mean_rank.png", True),
        (worst.set_index("algorithm").loc[GROUPS, "worst_layout_total_coverage"]
         .sort_values(ascending=False),
         "Worst fixed-layout coverage", "Minimum layout-level mean coverage (%)",
         "worst_layout_coverage.png", False),
    ]:
        fig, axis = plt.subplots(figsize=(7.2, 5.2), constrained_layout=True)
        labels = [DISPLAY_LABELS.get(label, label) for label in values.index]
        colors = [COLORS[GROUPS.index(label)] for label in values.index]
        axis.barh(np.arange(len(values)), values, color=colors)
        axis.set_yticks(np.arange(len(values)), labels, fontsize=8)
        axis.invert_yaxis()
        if invert_x:
            axis.invert_xaxis()
        axis.set_title(title, fontweight="bold")
        axis.set_xlabel(xlabel)
        axis.grid(axis="x", linestyle=":", alpha=0.35)
        axis.spines[["top", "right"]].set_visible(False)
        fig.savefig(os.path.join(ROOT, filename), dpi=260, bbox_inches="tight")
        plt.close(fig)


def write_report(data, ranks, worst, statistic, p_value, runs):
    overall = data.groupby("algorithm")[["total_coverage", "special_coverage",
                                          "best_fitness"]].agg(["mean", "std"])
    fitness_ranks = (ranks[ranks.metric == "best_fitness"]
                     .groupby("algorithm")["rank"].mean())
    best = fitness_ranks.idxmin()
    lines = [
        "# v3.1 跨布局泛化实验", "",
        "本实验统一采用 M=20、SINR门限0 dB、20个粒子、每次精确6000 FEs。",
        f"共6个固定布局（3类×2），每个布局{runs}个配对优化种子，"
        f"10种算法，共{6 * runs * len(GROUPS)}次运行。", "",
        "注意：第三类采用‘边缘重点区域/边缘用户需求’，未声称模拟建筑穿透或遮挡信道。",
        "v3.1在每个新布局上从头运行并在线更新，因此结论是端到端优化器的跨实例稳健性，",
        "不是冻结策略的零样本迁移能力。", "",
        f"综合适应度跨布局平均排名第一：{best}（平均秩 {fitness_ranks[best]:.3f}）。",
        f"Friedman检验：chi2={statistic:.4f}, p={p_value:.6g}。", "",
        "排名与显著性结果见本次运行输出的CSV文件。", "",
        "## 总体结果（均值±标准差）", "",
        "|算法|总覆盖率(%)|重点覆盖率(%)|综合适应度|最差布局覆盖率(%)|适应度平均秩|",
        "|---|---:|---:|---:|---:|---:|",
    ]
    worst_index = worst.set_index("algorithm")
    for label in GROUPS:
        row = overall.loc[label]
        lines.append(
            f"|{label}|{row[('total_coverage','mean')]:.3f}±{row[('total_coverage','std')]:.3f}"
            f"|{row[('special_coverage','mean')]:.3f}±{row[('special_coverage','std')]:.3f}"
            f"|{row[('best_fitness','mean')]:.4f}±{row[('best_fitness','std')]:.4f}"
            f"|{worst_index.loc[label, 'worst_layout_total_coverage']:.3f}"
            f"|{fitness_ranks[label]:.3f}|")
    lines.extend(["", "完整原始结果、分布局汇总、最差布局表、平均排名、Wilcoxon-Holm检验及图表均在本目录。", ""])
    with open(os.path.join(ROOT, "README.md"), "w", encoding="utf-8") as stream:
        stream.write("\n".join(lines))


def write_protocol(args):
    protocol = {
        "registered_utc": datetime.now(timezone.utc).isoformat(),
        "target": TARGET, "comparators": GROUPS[1:],
        "scenario": {"uavs": args.uavs, "sinr_threshold_db": args.threshold_db,
                     "particles": args.particles, "function_evaluations": args.budget},
        "pso_parameters": {"inertia_weight": 0.7, "c1": 1.6, "c2": 1.8},
        "design": {"layout_types": 3, "fixed_layouts_per_type": 2,
                   "optimizer_seeds_per_layout": args.runs,
                   "paired_seeds": True, "total_runs": 6 * args.runs * len(GROUPS)},
        "metrics": ["total_coverage", "special_coverage", "best_fitness",
                    "cross_layout_average_rank", "worst_layout_performance"],
    }
    path = os.path.join(ROOT, "protocol.json")
    with open(path, "w", encoding="utf-8") as stream:
        json.dump(protocol, stream, indent=2, ensure_ascii=False)


def validate_existing_rows(rows, args, *, source):
    """阻止不同场景或函数评价次数的旧结果被当成当前结果。"""
    layout_ids = {item[0] for item in LAYOUT_SPECS}
    for row in rows:
        try:
            valid = (
                str(row["algorithm"]) in GROUPS
                and str(row["layout_id"]) in layout_ids
                and 1 <= int(float(row["run"])) <= args.runs
                and int(float(row["particles"])) == args.particles
                and int(float(row["fe_budget"])) == args.budget
                and int(float(row["uavs"])) == args.uavs
                and np.isclose(float(row["threshold_db"]), args.threshold_db)
            )
        except (KeyError, TypeError, ValueError):
            valid = False
        if not valid:
            raise ValueError(
                f"{source} 中存在与当前协议不一致的旧结果；"
                "请改用新的 --output-root，或显式使用 --fresh 覆盖结果文件")


def main():
    global ROOT, LAYOUT_ROOT
    parser = argparse.ArgumentParser()
    parser.add_argument("--runs", type=int, default=CROSS_LAYOUT_SEEDS_PER_LAYOUT)
    parser.add_argument("--particles", type=int, default=PARTICLES)
    parser.add_argument(
        "--function-evaluations", "--budget", dest="budget",
        type=int, default=FE_BUDGET,
        help="最大函数评价次数；--budget 仅为旧命令兼容名",
    )
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--uavs", type=int, default=20)
    parser.add_argument("--threshold-db", type=float, default=0.0)
    parser.add_argument("--algorithms", nargs="+", choices=GROUPS)
    parser.add_argument("--layouts", nargs="+", choices=[x[0] for x in LAYOUT_SPECS])
    parser.add_argument("--output-root", default=ROOT)
    parser.add_argument("--fresh", action="store_true",
                        help="忽略并覆盖当前输出目录中的结果 CSV")
    args = parser.parse_args()
    if args.runs <= 0 or args.particles <= 0 or args.budget <= 0:
        raise ValueError("runs、particles 和 function-evaluations 必须为正数")
    if args.workers <= 0 or args.uavs <= 0:
        raise ValueError("workers 和 uavs 必须为正数")
    ROOT = args.output_root; LAYOUT_ROOT = os.path.join(ROOT, "layouts")
    os.makedirs(ROOT, exist_ok=True)
    manifest = load_manifest()
    selected_layouts = set(args.layouts or manifest.layout_id)
    selected_algorithms = args.algorithms or GROUPS
    result_path = os.path.join(ROOT, "results.csv")
    history_path = os.path.join(ROOT, "histories.csv")
    rows = (pd.read_csv(result_path).to_dict("records")
            if not args.fresh and os.path.exists(result_path) else [])
    histories = (pd.read_csv(history_path).to_dict("records")
                 if not args.fresh and os.path.exists(history_path) else [])
    rows = [row for row in rows if str(row["algorithm"]) in GROUPS]
    histories = [row for row in histories if str(row["algorithm"]) in GROUPS]
    validate_existing_rows(rows, args, source="results.csv")
    validate_existing_rows(histories, args, source="histories.csv")
    write_protocol(args)
    completed = {(str(row["algorithm"]), str(row["layout_id"]), int(row["seed"]))
                 for row in rows}
    tasks = []
    for _, layout in manifest.iterrows():
        if layout.layout_id not in selected_layouts:
            continue
        layout_dict = layout.to_dict()
        for run in range(1, args.runs + 1):
            seed = 31001 + 100 * (run - 1)
            for algorithm in selected_algorithms:
                if (algorithm, layout.layout_id, seed) not in completed:
                    tasks.append({"algorithm": algorithm, "layout": layout_dict,
                                  "run": run, "seed": seed, "particles": args.particles,
                                  "budget": args.budget, "uavs": args.uavs,
                                  "threshold_db": args.threshold_db})
    total_expected = len(GROUPS) * len(LAYOUT_SPECS) * args.runs
    print(f"pending={len(tasks)} existing={len(rows)} formal_expected={total_expected}", flush=True)
    if args.workers <= 1:
        outputs = map(run_one, tasks)
        for result, history in outputs:
            rows.append(result); histories.extend(history)
            pd.DataFrame(rows).to_csv(result_path, index=False, encoding="utf-8-sig")
            pd.DataFrame(histories).to_csv(history_path, index=False, encoding="utf-8-sig")
            print(f"{len(rows):03d}/{total_expected} {result['layout_id']} {result['algorithm']} "
                  f"run={result['run']:02d} cov={result['total_coverage']:.3f} "
                  f"fit={result['best_fitness']:.4f} audit={result['audit_ok']}", flush=True)
    else:
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            futures = [pool.submit(run_one, task) for task in tasks]
            for future in as_completed(futures):
                result, history = future.result()
                rows.append(result); histories.extend(history)
                pd.DataFrame(rows).to_csv(result_path, index=False, encoding="utf-8-sig")
                pd.DataFrame(histories).to_csv(history_path, index=False, encoding="utf-8-sig")
                print(f"{len(rows):03d}/{total_expected} {result['layout_id']} {result['algorithm']} "
                      f"run={result['run']:02d} cov={result['total_coverage']:.3f} "
                      f"fit={result['best_fitness']:.4f} audit={result['audit_ok']}", flush=True)
    print(f"aggregate_complete={analyse(pd.DataFrame(rows), args.runs, args.budget)}", flush=True)


if __name__ == "__main__":
    main()
