import sys

from 实验代码.消融实验.run_equal_time import main


def add_default(flag: str, value: str) -> None:
    if flag not in sys.argv[1:]:
        sys.argv.extend([flag, value])


if __name__ == "__main__":
    add_default("--threshold", "3")
    add_default("--uavs", "10")
    add_default("--time-budget", "10")
    add_default("--checkpoint-interval", "1")
    add_default("--seed-base", "14080042")
    add_default("--output", "实验结果/02_等时间实验/3dB_M10_10秒")
    main()
