# -*- coding: utf-8 -*-
"""Run ablation experiments with equal wall-clock limits.

计时区间只包含优化器更新，不包含场景建立、归一化标定、进程启动、预热、
优化器构造、最终汇总和文件写入。各组使用相同硬时间上限，并在最后一个完整
更新结束后停止。
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")

import numpy as np
import pandas as pd
import torch

from 算法代码.registry import (
    ARPG_PSO_v31,
    ARPG_PSO_v31_Ablation,
    PAPER_ALGORITHM_CLASSES,
)
import model
from model import calibrate_normalization, load_special_area
from exp_config import (
    ABLATION_ORDER,
    LEGACY_ABLATION_ALIASES,
    PARTICLES,
    RUNS_PER_SCENARIO,
    TARGET,
    canonical_ablation_label,
)
from exp_utils import configure_scenario, final_metrics


ROOT = os.path.join("实验结果", "02_等时间实验")
ALGORITHMS = {
    ("ARPG-PSO" if name == TARGET else name): algorithm
    for name, algorithm in PAPER_ALGORITHM_CLASSES.items()
}

ABLATION_GROUPS = {
    "Base-only": {
        "acceptance_mode": "disabled",
        "learning_mode": "frozen",
    },
    "Frozen-Actor": {"learning_mode": "frozen"},
    "No-selection": {"acceptance_mode": "always"},
    "Full-v3.1": {},
}

if tuple(ABLATION_GROUPS) != ABLATION_ORDER:
    raise RuntimeError("等时间消融组别与实验配置不一致")

AVAILABLE_LABELS = (
    list(ALGORITHMS)
    + list(ABLATION_GROUPS)
    + list(LEGACY_ABLATION_ALIASES)
)


def set_torch_threads():
    torch.set_num_threads(1)
    try:
        torch.set_num_interop_threads(1)
    except RuntimeError:
        pass


def make_optimizer(label, p, area, particles):
    label = canonical_ablation_label(label)
    if label in ABLATION_GROUPS:
        return ARPG_PSO_v31_Ablation(
            p, area, num_particles=particles,
            **ABLATION_GROUPS[label])
    cls = ALGORITHMS[label]
    if label == "ARPG-PSO":
        return cls(p, area, num_particles=particles,
                   acceptance_mode="certified")
    return cls(p, area, num_particles=particles)


def seed_everything(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)


def estimate_generation_time(label, p, area, particles, pilot_iterations,
                             pilot_seconds, pilot_seed):
    """Warm caches, then estimate a generation duration on a discarded run."""
    seed_everything(pilot_seed - 1)
    warmup = make_optimizer(label, p, area, particles)
    for iteration in range(2):
        warmup.update(iteration, 2)
    del warmup

    seed_everything(pilot_seed)
    pilot = make_optimizer(label, p, area, particles)
    durations = []
    pilot_horizon = max(20, pilot_iterations)
    pilot_started = time.perf_counter()
    iteration = 0
    while (iteration < pilot_iterations
           or time.perf_counter() - pilot_started < pilot_seconds):
        started = time.perf_counter()
        pilot.update(iteration, pilot_horizon)
        durations.append(time.perf_counter() - started)
        iteration += 1
    del pilot
    return durations


def run_timed_once(label, p, area, particles, time_budget, seed,
                   pilot_durations, guard_factor, horizon_scale=1.05,
                   checkpoint_interval=2.0):
    median_step = float(np.median(pilot_durations))
    mean_step = float(np.mean(pilot_durations))
    p90_step = float(np.quantile(pilot_durations, 0.90))
    schedule_horizon = max(
        2, int(np.ceil(horizon_scale * time_budget / mean_step)))

    seed_everything(seed)
    optimizer = make_optimizer(label, p, area, particles)
    step_durations = []
    checkpoints = np.arange(
        checkpoint_interval, time_budget + checkpoint_interval * 0.5,
        checkpoint_interval, dtype=float)
    checkpoints = checkpoints[checkpoints <= time_budget + 1e-9]
    checkpoint_snapshots = []
    next_checkpoint = 0
    iteration = 0
    compute_elapsed = 0.0

    def snapshot(checkpoint_seconds, source_elapsed, source_iteration,
                 source_fes, position, fitness):
        checkpoint_snapshots.append({
            "checkpoint_seconds": float(checkpoint_seconds),
            "source_elapsed_seconds": float(source_elapsed),
            "iteration": int(source_iteration),
            "actual_fes": int(source_fes),
            "best_fitness": float(fitness),
            "best_position": np.asarray(position, dtype=float).tolist(),
        })

    last_position = None
    last_fitness = None
    last_fes = 0
    last_iteration = 0
    last_elapsed = 0.0
    while iteration < schedule_horizon:
        recent = step_durations[-10:]
        observed_p90 = (float(np.quantile(recent, 0.90))
                        if recent else p90_step)
        predicted = max(p90_step, observed_p90) * guard_factor
        if time_budget - compute_elapsed < max(predicted, 0.002):
            break

        step_started = time.perf_counter()
        optimizer.update(iteration, schedule_horizon)
        step_finished = time.perf_counter()
        duration = step_finished - step_started
        step_durations.append(duration)
        compute_elapsed += duration
        current_position, current_fitness = optimizer.get_best_solution()
        current_position = np.asarray(current_position, dtype=float).copy()
        if last_position is None:
            # Some implementations establish gbest only in their first update.
            last_position = current_position
            last_fitness = current_fitness
            last_fes = int(optimizer.evaluation_count)
            last_iteration = iteration + 1
            last_elapsed = compute_elapsed
        while (next_checkpoint < len(checkpoints)
               and compute_elapsed >= checkpoints[next_checkpoint]):
            snapshot(checkpoints[next_checkpoint], last_elapsed,
                     last_iteration, last_fes, last_position, last_fitness)
            next_checkpoint += 1
        iteration += 1
        last_position, last_fitness = current_position, current_fitness
        last_fes = int(optimizer.evaluation_count)
        last_iteration = iteration
        last_elapsed = compute_elapsed

    elapsed = compute_elapsed
    while next_checkpoint < len(checkpoints):
        snapshot(checkpoints[next_checkpoint], last_elapsed,
                 last_iteration, last_fes, last_position, last_fitness)
        next_checkpoint += 1
    best_position, best_fitness = optimizer.get_best_solution()
    total, special, general, f1, f2, f3 = final_metrics(
        best_position, p, area)
    pending_rollout = 0
    sampled_actions = executed_transitions = 0
    final_ratio = 1.0
    if isinstance(optimizer, ARPG_PSO_v31):
        pending_rollout = len(optimizer.mappo.rollout["states"])
        sampled_actions = optimizer.mappo.sampled_action_count
        executed_transitions = optimizer.mappo.executed_transition_count
        final_ratio = optimizer.mappo.last_ratio_mean

    result = {
        "algorithm": label,
        "seed": seed,
        "time_budget_seconds": time_budget,
        "elapsed_seconds": elapsed,
        "unused_seconds": time_budget - elapsed,
        "budget_utilization": elapsed / time_budget,
        "iterations_completed": iteration,
        "schedule_horizon": schedule_horizon,
        "actual_fes": int(optimizer.evaluation_count),
        "milliseconds_per_fe": (
            1000.0 * elapsed / max(1, optimizer.evaluation_count)),
        "best_fitness": float(best_fitness),
        "total_coverage": total,
        "special_coverage": special,
        "general_coverage": general,
        "f1_uncov": f1,
        "f2_spec_std": f2,
        "f3_gen_std": f3,
        "pilot_median_generation_seconds": median_step,
        "pilot_mean_generation_seconds": mean_step,
        "pilot_p90_generation_seconds": p90_step,
        "max_observed_generation_seconds": float(max(step_durations)),
        "guard_factor": guard_factor,
        "horizon_scale": horizon_scale,
        "time_cap_ok": bool(elapsed <= time_budget),
        "pending_rollout_steps": pending_rollout,
        "sampled_actions": sampled_actions,
        "executed_transitions": executed_transitions,
        "final_ppo_ratio": final_ratio,
    }
    checkpoint_history = []
    for row in checkpoint_snapshots:
        position = row.pop("best_position")
        cp_total, cp_special, cp_general, cp_f1, cp_f2, cp_f3 = final_metrics(
            position, p, area)
        row.update({
            "total_coverage": cp_total,
            "special_coverage": cp_special,
            "general_coverage": cp_general,
            "f1_uncov": cp_f1,
            "f2_spec_std": cp_f2,
            "f3_gen_std": cp_f3,
        })
        checkpoint_history.append(row)
    return result, checkpoint_history


def run_worker(args):
    set_torch_threads()
    args.worker_algorithm = canonical_ablation_label(args.worker_algorithm)
    p = configure_scenario(args.uavs, args.threshold, 10**9)
    area = load_special_area()
    if args.norm_mu and args.norm_sigma:
        model._NORM["mu"] = np.fromstring(args.norm_mu, sep=",")
        model._NORM["sigma"] = np.fromstring(args.norm_sigma, sep=",")
        model._NORM["ready"] = True
    else:
        calibrate_normalization(p["size"], area, num_samples=60, seed=0)

    pilot_seed = 900000 + args.seed
    pilot = estimate_generation_time(
        args.worker_algorithm, p, area, args.particles,
        args.pilot_iterations, args.pilot_seconds, pilot_seed)

    guard = args.guard_factor
    horizon_scale = 1.05
    result = trajectory = None
    for attempt in range(1, 5):
        result, trajectory = run_timed_once(
            args.worker_algorithm, p, area, args.particles,
            args.time_budget, args.seed, pilot, guard, horizon_scale,
            args.checkpoint_interval)
        result["attempt"] = attempt
        ended_at_horizon = (
            result["iterations_completed"] >= result["schedule_horizon"])
        if (result["time_cap_ok"]
                and not (ended_at_horizon
                         and result["budget_utilization"] < 0.95)):
            break
        if not result["time_cap_ok"]:
            guard *= 1.5
        else:
            horizon_scale *= (
                args.time_budget / max(result["elapsed_seconds"], 1e-9)) * 1.03
    if not result["time_cap_ok"]:
        raise RuntimeError(
            f"{args.worker_algorithm} exceeded the hard time cap after retries")

    result.update({
        "gamma_th_db": args.threshold,
        "num_uavs": args.uavs,
        "particles": args.particles,
        "run": args.worker_run + 1,
        "execution_order": args.execution_order,
        "checkpoint_interval_seconds": args.checkpoint_interval,
        "timing_protocol": (
            "fresh_process_single_thread_warmup_pilot_"
            "fixed_checkpoints_last_completed_generation"),
    })
    payload = {"result": result, "trajectory": trajectory}
    os.makedirs(os.path.dirname(args.worker_output), exist_ok=True)
    with open(args.worker_output, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)
    print(
        f"{args.worker_algorithm} run={args.worker_run + 1:02d} "
        f"time={result['elapsed_seconds']:.3f}/{args.time_budget:.3f}s "
        f"FEs={result['actual_fes']} coverage={result['total_coverage']:.3f}% "
        f"fitness={result['best_fitness']:.4f}", flush=True)


def worker_payload_matches(payload, *, label, run, seed, args):
    """只复用与当前实验协议完全一致的工作进程结果。"""
    try:
        result = payload["result"]
        trajectory = payload["trajectory"]
        expected = {
            "algorithm": label,
            "run": run + 1,
            "seed": seed,
            "num_uavs": args.uavs,
            "particles": args.particles,
        }
        if any(result.get(key) != value for key, value in expected.items()):
            return False
        numeric_expected = {
            "gamma_th_db": args.threshold,
            "time_budget_seconds": args.time_budget,
            "checkpoint_interval_seconds": args.checkpoint_interval,
        }
        if any(not np.isclose(float(result.get(key)), float(value))
               for key, value in numeric_expected.items()):
            return False
        expected_checkpoints = int(np.floor(
            args.time_budget / args.checkpoint_interval + 1e-9))
        return len(trajectory) == expected_checkpoints
    except (KeyError, TypeError, ValueError):
        return False


def run_controller(args):
    os.makedirs(args.output, exist_ok=True)
    worker_dir = os.path.join(args.output, "worker_results")
    os.makedirs(worker_dir, exist_ok=True)
    results_path = os.path.join(args.output, "raw_results.csv")
    trajectories_path = os.path.join(args.output, "time_histories.csv")

    labels = [canonical_ablation_label(label) for label in (
        args.algorithms or ABLATION_ORDER)]
    if len(labels) != len(set(labels)):
        raise ValueError("算法列表在旧名称转换后出现重复项")
    p = configure_scenario(args.uavs, args.threshold, 10**9)
    area = load_special_area()
    norm_mu, norm_sigma = calibrate_normalization(
        p["size"], area, num_samples=60, seed=0)
    norm_mu_text = ",".join(f"{value:.17g}" for value in norm_mu)
    norm_sigma_text = ",".join(f"{value:.17g}" for value in norm_sigma)
    schedule_rng = np.random.default_rng(args.schedule_seed)
    schedule = []
    for run in range(args.runs):
        for label in schedule_rng.permutation(labels):
            schedule.append((run, str(label)))

    results = []
    histories = []
    for order, (run, label) in enumerate(schedule, start=1):
        seed = args.seed_base + 100 * run
        safe_label = label.replace("/", "_")
        output = os.path.join(
            worker_dir, f"run{run + 1:02d}_{safe_label}.json")
        payload = None
        if os.path.exists(output):
            with open(output, "r", encoding="utf-8") as handle:
                candidate = json.load(handle)
            if worker_payload_matches(
                    candidate, label=label, run=run, seed=seed, args=args):
                payload = candidate
            else:
                print(f"忽略协议不匹配的旧结果: {output}", flush=True)
        if payload is None:
            command = [
                sys.executable,
                "-m",
                "实验代码.消融实验.run_equal_time",
                "--worker",
                "--worker-algorithm", label,
                "--worker-run", str(run),
                "--execution-order", str(order),
                "--worker-output", output,
                "--threshold", str(args.threshold),
                "--uavs", str(args.uavs),
                "--particles", str(args.particles),
                "--time-budget", str(args.time_budget),
                "--checkpoint-interval", str(args.checkpoint_interval),
                "--seed", str(seed),
                "--pilot-iterations", str(args.pilot_iterations),
                "--pilot-seconds", str(args.pilot_seconds),
                "--guard-factor", str(args.guard_factor),
                "--norm-mu", norm_mu_text,
                "--norm-sigma", norm_sigma_text,
            ]
            completed = subprocess.run(
                command, check=False, text=True, capture_output=True)
            if completed.returncode != 0:
                details = completed.stderr.strip() or completed.stdout.strip()
                raise RuntimeError(
                    f"工作进程失败：{label}，run={run + 1}\n{details}")
            print(completed.stdout.strip(), flush=True)
            with open(output, "r", encoding="utf-8") as handle:
                payload = json.load(handle)
            if not worker_payload_matches(
                    payload, label=label, run=run, seed=seed, args=args):
                raise RuntimeError(f"新生成结果未通过协议校验: {output}")
        results.append(payload["result"])
        histories.extend({
            "algorithm": payload["result"]["algorithm"],
            "run": payload["result"]["run"],
            "seed": payload["result"]["seed"],
            **row,
        } for row in payload["trajectory"])
        pd.DataFrame(results).to_csv(
            results_path, index=False, encoding="utf-8-sig")
        pd.DataFrame(histories).to_csv(
            trajectories_path, index=False, encoding="utf-8-sig")

    protocol = {
        "threshold_db": args.threshold,
        "uavs": args.uavs,
        "particles": args.particles,
        "time_budget_seconds": args.time_budget,
        "checkpoint_interval_seconds": args.checkpoint_interval,
        "runs": args.runs,
        "paired_seed_base": args.seed_base,
        "algorithms": labels,
        "normalization_mu": norm_mu.tolist(),
        "normalization_sigma": norm_sigma.tolist(),
        "execution": "fresh processes, randomized order, strictly serial",
        "timed_region": "optimizer update loop only",
        "excluded": [
            "process startup", "scenario setup", "normalization calibration",
            "warm-up and timing pilot", "optimizer construction",
            "final metric reporting", "file I/O"],
        "stopping_rule": "last safely completed generation before deadline",
        "checkpoint_rule": (
            "best solution from the last generation completed no later than "
            "each fixed checkpoint; metric reporting is performed afterward"),
    }
    with open(os.path.join(args.output, "protocol.json"), "w",
              encoding="utf-8") as handle:
        json.dump(protocol, handle, ensure_ascii=False, indent=2)
    print(f"COMPLETED: {len(results)} equal-time runs", flush=True)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runs", type=int, default=RUNS_PER_SCENARIO)
    parser.add_argument("--threshold", type=float, default=0.0)
    parser.add_argument("--uavs", type=int, default=20)
    parser.add_argument("--particles", type=int, default=PARTICLES)
    parser.add_argument("--time-budget", type=float, default=30.0)
    parser.add_argument("--checkpoint-interval", type=float, default=2.0)
    parser.add_argument("--seed-base", type=int, default=80042)
    parser.add_argument("--schedule-seed", type=int, default=20260826)
    parser.add_argument("--pilot-iterations", type=int, default=10)
    parser.add_argument("--pilot-seconds", type=float, default=0.5)
    parser.add_argument("--guard-factor", type=float, default=1.20)
    parser.add_argument("--output", default=ROOT)
    parser.add_argument("--algorithms", nargs="+", choices=AVAILABLE_LABELS)
    parser.add_argument("--worker", action="store_true")
    parser.add_argument("--worker-algorithm", choices=AVAILABLE_LABELS)
    parser.add_argument("--worker-run", type=int, default=0)
    parser.add_argument("--execution-order", type=int, default=0)
    parser.add_argument("--worker-output")
    parser.add_argument("--seed", type=int, default=80042)
    parser.add_argument("--norm-mu")
    parser.add_argument("--norm-sigma")
    return parser.parse_args()


def main():
    args = parse_args()
    if args.runs <= 0 or args.particles <= 0 or args.time_budget <= 0:
        raise ValueError("runs、particles 和 time-budget 必须为正数")
    if not 0 < args.checkpoint_interval <= args.time_budget:
        raise ValueError("checkpoint-interval 必须大于0且不超过 time-budget")
    if args.worker:
        if not args.worker_algorithm or not args.worker_output:
            raise ValueError("worker algorithm and output are required")
        run_worker(args)
    else:
        run_controller(args)


if __name__ == "__main__":
    main()
