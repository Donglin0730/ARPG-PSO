# -*- coding: utf-8 -*-
from __future__ import annotations

import numpy as np

from .ARPG_PSO import ARPG_PSO_v31


class ARPG_PSO_v31_Ablation(ARPG_PSO_v31):
    """Construct ablation variants using explicit mechanism switches."""

    def __init__(self, p, special_area, num_particles=20,
                 acceptance_mode='certified', learning_mode='mappo',
                 elite_mode='distribution', trust_mode='adaptive',
                 reward_mode='counterfactual'):
        if elite_mode not in {'distribution', 'single_gbest'}:
            raise ValueError('unknown elite_mode')
        if trust_mode not in {'adaptive', 'fixed'}:
            raise ValueError('unknown trust_mode')
        if reward_mode not in {'counterfactual', 'population_relative'}:
            raise ValueError('unknown reward_mode')
        self.elite_mode = elite_mode
        self.trust_mode = trust_mode
        self.reward_mode = reward_mode
        super().__init__(
            p, special_area, num_particles=num_particles,
            rollout_length=5, actor_residual_scale=0.30,
            acceptance_mode=acceptance_mode, learning_mode=learning_mode,
            reward_scale=10.0, initial_log_std=-1.9,
            policy_action_mode='gate_and_vector')
        self.fixed_trust_radius = 0.45

    def _elite_field(self):
        if self.elite_mode == 'distribution':
            return super()._elite_field()
        center = self.gbest_position.copy()
        spread = np.std(self.pbest_positions, axis=0)
        spread = np.maximum(spread, 0.015 * self.span)
        return center, spread

    def _counterfactual_rewards(self, base_fitness, policy_fitness,
                                base_quality=None, policy_quality=None):
        if self.reward_mode == 'counterfactual':
            return super()._counterfactual_rewards(
                base_fitness, policy_fitness, base_quality, policy_quality)
        scale = max(float(np.std(policy_fitness)), 1e-6)
        return np.clip(
            -(policy_fitness - float(np.mean(policy_fitness))) / scale,
            -1.0, 1.0)

    def update(self, iteration, max_iterations):
        if self.trust_mode == 'fixed':
            self.trust_radius = self.fixed_trust_radius
        result = super().update(iteration, max_iterations)
        if self.trust_mode == 'fixed':
            self.trust_radius = self.fixed_trust_radius
        return result
