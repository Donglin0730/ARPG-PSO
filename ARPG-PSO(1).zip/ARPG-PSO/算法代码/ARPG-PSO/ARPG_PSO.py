# -*- coding: utf-8 -*-
from __future__ import annotations

import time

import numpy as np

from model import (canshu, init_base_station, update_coverage,
                   objective_function, calculate_coverage_and_uniformity,
                   calibrate_normalization, load_special_area)
from 算法代码.公共组件.mappo import ShieldedResidualMAPPO


class ARPG_PSO_v31:
    """Counterfactual-shielded residual MAPPO-guided PSO."""

    def __init__(self, p, special_area, num_particles=20, elite_ratio=0.25,
                 rollout_length=5, actor_residual_scale=0.30,
                 acceptance_mode='certified', learning_mode='mappo',
                 reward_scale=10.0, initial_log_std=-1.9,
                 policy_action_mode='gate_and_vector'):
        self.p = p
        self.special_area = special_area
        self.num_particles = num_particles
        self.num_uavs = p['num_base_stations']
        self.dim = self.num_uavs * 3
        self.size = p['size']
        self.h_min, self.h_max = p['h_min'], p['h_max']
        self.elite_ratio = elite_ratio
        self.rollout_length = rollout_length
        self.actor_residual_scale = actor_residual_scale
        self.reward_scale = float(reward_scale)
        if acceptance_mode not in {'certified', 'always', 'disabled'}:
            raise ValueError(
                'acceptance_mode must be certified, always, or disabled')
        self.acceptance_mode = acceptance_mode
        if learning_mode not in {'mappo', 'frozen'}:
            raise ValueError('learning_mode must be mappo or frozen')
        self.learning_mode = learning_mode
        if policy_action_mode not in {'gate_and_vector', 'gate_only'}:
            raise ValueError(
                'policy_action_mode must be gate_and_vector or gate_only')
        self.policy_action_mode = policy_action_mode

        low_one = np.array([0.0, 0.0, self.h_min], dtype=float)
        high_one = np.array([self.size - 1.0, self.size - 1.0,
                             self.h_max], dtype=float)
        self.lower_one = low_one
        self.upper_one = high_one
        self.span_one = high_one - low_one
        self.lower = np.tile(low_one, self.num_uavs)
        self.upper = np.tile(high_one, self.num_uavs)
        self.span = self.upper - self.lower
        self.positions = np.random.uniform(
            self.lower, self.upper, size=(num_particles, self.dim))
        self.velocities = np.zeros_like(self.positions)
        self.pbest_positions = self.positions.copy()
        self.pbest_fitness = np.full(num_particles, np.inf)
        self.gbest_position = None
        self.gbest_fitness = np.inf
        self.stagnation = 0
        self.trust_radius = 0.45
        self.success_ema = 0.20
        self.mappo = ShieldedResidualMAPPO(
            self.num_uavs,
            action_dim=(1 if policy_action_mode == 'gate_only' else 4),
            learning_rate=p.get('learning_rate', 3e-4),
            gamma=p.get('gamma', 0.97),
            gae_lambda=p.get('gae_lambda', 0.95),
            clip_epsilon=p.get('clip_epsilon', 0.2),
            entropy_coef=p.get('entropy_coef', 0.002),
            ppo_epochs=p.get('ppo_epochs', 4),
            initial_log_std=initial_log_std)

        self.last_base_fitness = np.full(num_particles, np.inf)
        self.last_policy_fitness = np.full(num_particles, np.inf)
        self.last_selected_fitness = np.full(num_particles, np.inf)
        self.last_signed_advantages = np.zeros(num_particles)
        self.last_old_log_probs = np.empty((num_particles, self.num_uavs))
        self.evaluation_count = 0
        self.history = {
            'fitness': [], 'coverage': [], 'special_coverage': [],
            'general_coverage': [], 'trust_radius': [],
            'residual_success_rate': [], 'mean_policy_gate': [],
            'mean_reward': [], 'ppo_ratio': [], 'actor_loss': [],
            'critic_loss': [],
        }

    def _evaluate(self, flat_position):
        self.evaluation_count += 1
        position = np.asarray(flat_position).reshape(self.num_uavs, 3)
        grid = np.zeros((self.size, self.size), dtype=float)
        coverage = np.zeros((self.size, self.size), dtype=int)
        stations = [init_base_station(row[2], (row[0], row[1]))
                    for row in position]
        update_coverage(grid, coverage, stations, self.size)
        return objective_function(
            self.size, grid, coverage, self.special_area)

    def _evaluate_population(self, positions):
        return np.asarray([self._evaluate(position) for position in positions])

    def _counterfactual_rewards(self, base_fitness, policy_fitness,
                                base_quality=None, policy_quality=None):
        """Reward hook; subclasses may add already-computed quality gains."""
        signed_advantage = base_fitness - policy_fitness
        return np.clip(
            self.reward_scale * signed_advantage
            / np.maximum(np.abs(base_fitness), 1e-6), -1.0, 1.0)

    def _update_bests(self, fitness, positions):
        improved = fitness < self.pbest_fitness
        self.pbest_fitness[improved] = fitness[improved]
        self.pbest_positions[improved] = positions[improved]
        best = int(np.argmin(fitness))
        if fitness[best] < self.gbest_fitness:
            self.gbest_fitness = float(fitness[best])
            self.gbest_position = positions[best].copy()
            return True
        return False

    def _population_context(self, fitness, iteration, max_iterations):
        scaled = (self.positions - self.lower) / self.span
        diversity = float(np.mean(np.std(scaled, axis=0)))
        progress = iteration / max(1, max_iterations - 1)
        order = np.argsort(fitness)
        rank = np.empty(self.num_particles, dtype=float)
        rank[order] = (np.arange(self.num_particles)
                       / max(1, self.num_particles - 1))
        stagnant = min(self.stagnation, 20) / 20.0
        return progress, rank, diversity, stagnant

    def _elite_field(self):
        count = max(2, int(np.ceil(self.elite_ratio * self.num_particles)))
        elite_ids = np.argsort(self.pbest_fitness)[:count]
        elite = self.pbest_positions[elite_ids]
        shifted = self.pbest_fitness[elite_ids] - self.pbest_fitness[elite_ids].min()
        weights = np.exp(-shifted / max(float(np.std(shifted)), 1e-6))
        weights /= weights.sum()
        center = np.sum(elite * weights[:, None], axis=0)
        spread = np.sqrt(np.sum(weights[:, None]
                                * np.square(elite - center), axis=0))
        spread = np.maximum(spread, 0.015 * self.span)
        return center, spread

    def _policy_states(self, base, elite_center, fitness, iteration,
                       max_iterations, proposal=None):
        progress, rank, diversity, stagnant = self._population_context(
            fitness, iteration, max_iterations)
        base_uav = base.reshape(self.num_particles, self.num_uavs, 3)
        pbest_uav = self.pbest_positions.reshape(
            self.num_particles, self.num_uavs, 3)
        gbest_uav = self.gbest_position.reshape(1, self.num_uavs, 3)
        elite_uav = elite_center.reshape(1, self.num_uavs, 3)
        scale = self.span_one.reshape(1, 1, 3)
        shared = np.stack([
            np.full(self.num_particles, progress), rank,
            np.full(self.num_particles, diversity),
            np.full(self.num_particles, stagnant),
        ], axis=1)
        shared = np.repeat(shared[:, None, :], self.num_uavs, axis=1)
        return np.concatenate([
            (base_uav - self.lower_one) / self.span_one,
            np.clip((pbest_uav - base_uav) / scale, -1.0, 1.0),
            np.clip((gbest_uav - base_uav) / scale, -1.0, 1.0),
            np.clip((elite_uav - base_uav) / scale, -1.0, 1.0),
            shared,
        ], axis=2).astype(np.float32)

    def _next_policy_states(self, fitness, iteration, max_iterations):
        """Exact post-shield state used for rollout-boundary bootstrapping."""
        elite_center, _ = self._elite_field()
        return self._policy_states(
            self.positions, elite_center, fitness,
            min(iteration + 1, max_iterations - 1), max_iterations)

    def _record_metrics(self):
        position = self.gbest_position.reshape(self.num_uavs, 3)
        grid = np.zeros((self.size, self.size), dtype=float)
        coverage = np.zeros((self.size, self.size), dtype=int)
        stations = [init_base_station(row[2], (row[0], row[1]))
                    for row in position]
        update_coverage(grid, coverage, stations, self.size)
        total, special, general, _, _ = calculate_coverage_and_uniformity(
            self.size, grid, coverage, self.special_area)
        self.history['fitness'].append(self.gbest_fitness)
        self.history['coverage'].append(total)
        self.history['special_coverage'].append(special)
        self.history['general_coverage'].append(general)
        self.history['trust_radius'].append(self.trust_radius)

    def update(self, iteration, max_iterations):
        current_fitness = self._evaluate_population(self.positions)
        self._update_bests(current_fitness, self.positions)
        previous_best = self.gbest_fitness

        w = 0.9 - 0.5 * iteration / max(1, max_iterations - 1)
        r1 = np.random.random(self.positions.shape)
        r2 = np.random.random(self.positions.shape)
        base_velocity = (w * self.velocities
                         + 1.6 * r1 * (self.pbest_positions - self.positions)
                         + 1.8 * r2 * (self.gbest_position - self.positions))
        vmax = 0.35 * self.span
        base_velocity = np.clip(base_velocity, -vmax, vmax)
        base = np.clip(self.positions + base_velocity, self.lower, self.upper)
        elite_center, elite_spread = self._elite_field()
        # The policy observes the actual pre-action environment state.  PSO's
        # base proposal is subsequently transformed by the sampled action.
        states = self._policy_states(
            self.positions, elite_center, current_fitness,
            iteration, max_iterations, proposal=base)
        actions, old_log_probs, values = self.mappo.sample_actions(states)
        base_fitness = self._evaluate_population(base)
        base_quality = getattr(self, '_latest_population_quality', None)
        if base_quality is not None:
            base_quality = np.asarray(base_quality).copy()
        gates = 0.5 * (actions[:, :, :1] + 1.0)
        if self.policy_action_mode == 'gate_only':
            learned_residual = np.zeros_like(base)
        else:
            learned_residual = actions[:, :, 1:].reshape(
                self.num_particles, self.dim)

        progress = iteration / max(1, max_iterations - 1)
        exploitation = 0.35 + 0.55 * progress
        attraction = (elite_center - base).reshape(
            self.num_particles, self.num_uavs, 3)
        noise_scale = 0.22 * (1.0 - progress) + 0.025
        noise = np.random.normal(size=base.shape) * elite_spread
        residual = self.trust_radius * (
            exploitation * (gates * attraction).reshape(
                self.num_particles, self.dim)
            + noise_scale * noise
            + self.actor_residual_scale * learned_residual * elite_spread)
        policy_candidate = np.clip(base + residual, self.lower, self.upper)
        if self.acceptance_mode == 'disabled':
            policy_fitness = base_fitness.copy()
            policy_quality = base_quality
        else:
            policy_fitness = self._evaluate_population(policy_candidate)
            policy_quality = getattr(self, '_latest_population_quality', None)
            if policy_quality is not None:
                policy_quality = np.asarray(policy_quality).copy()

        signed_advantage = base_fitness - policy_fitness
        if self.acceptance_mode == 'certified':
            accept = signed_advantage > 1e-12
        elif self.acceptance_mode == 'always':
            accept = np.ones(self.num_particles, dtype=bool)
        else:
            accept = np.zeros(self.num_particles, dtype=bool)
        selected = np.where(accept[:, None], policy_candidate, base)
        selected_fitness = np.where(accept, policy_fitness, base_fitness)
        # The default uses relative fitness gain. Communication-aware
        # descendants can add coverage/SINR gains already computed during the
        # same objective evaluations without consuming extra FEs.
        rewards = self._counterfactual_rewards(
            base_fitness, policy_fitness, base_quality, policy_quality)
        terminal = iteration == max_iterations - 1
        self.mappo.store_transition(
            states, actions, old_log_probs, rewards, values,
            np.full(self.num_particles, terminal, dtype=np.float32))

        self.velocities = selected - self.positions
        self.positions = selected
        improved_global = self._update_bests(selected_fitness, selected)
        self.stagnation = (0 if improved_global
                           or self.gbest_fitness < previous_best
                           else self.stagnation + 1)
        success_rate = float(accept.mean())
        self.success_ema = 0.85 * self.success_ema + 0.15 * success_rate
        self.trust_radius = float(np.clip(
            self.trust_radius * np.exp(0.35 * (self.success_ema - 0.20)),
            0.08, 0.85))

        actor_loss = critic_loss = 0.0
        if ((iteration + 1) % self.rollout_length == 0) or terminal:
            if self.learning_mode == 'mappo':
                next_states = self._next_policy_states(
                    selected_fitness, iteration, max_iterations)
                actor_loss, critic_loss = self.mappo.update(
                    next_states, terminal=terminal)
            else:
                self.mappo.clear_rollout()

        self.last_base_fitness = base_fitness.copy()
        self.last_policy_fitness = policy_fitness.copy()
        self.last_selected_fitness = selected_fitness.copy()
        self.last_signed_advantages = signed_advantage.copy()
        self.last_old_log_probs = old_log_probs.copy()
        self.history['residual_success_rate'].append(success_rate)
        self.history['mean_policy_gate'].append(float(gates.mean()))
        self.history['mean_reward'].append(float(rewards.mean()))
        self.history['ppo_ratio'].append(self.mappo.last_ratio_mean)
        self.history['actor_loss'].append(actor_loss)
        self.history['critic_loss'].append(critic_loss)
        self._record_metrics()
        return self.gbest_fitness

    def train(self, num_iterations=100):
        for iteration in range(num_iterations):
            self.update(iteration, num_iterations)
        best = self.gbest_position.reshape(self.num_uavs, 3).tolist()
        return best, self.gbest_fitness, self.history

    def get_best_solution(self):
        return (self.gbest_position.reshape(self.num_uavs, 3).tolist(),
                self.gbest_fitness)


def main():
    p = canshu()
    p['max_iterations'] = 100
    p['learning_rate'] = 3e-4
    special_area = load_special_area()
    calibrate_normalization(p['size'], special_area, num_samples=60, seed=0)
    optimizer = ARPG_PSO_v31(p, special_area, num_particles=20)
    started = time.perf_counter()
    _, fitness, history = optimizer.train(p['max_iterations'])
    elapsed = time.perf_counter() - started
    print(f'ARPG-PSO v3.1 completed in {elapsed:.2f}s')
    print(f'fitness={fitness:.4f}, coverage={history["coverage"][-1]:.2f}%, '
          f'special={history["special_coverage"][-1]:.2f}%')
    print(f'acceptance={np.mean(history["residual_success_rate"]):.3f}, '
          f'gate={history["mean_policy_gate"][-1]:.3f}, '
          f'ppo_ratio={history["ppo_ratio"][-1]:.4f}')


if __name__ == '__main__':
    main()
