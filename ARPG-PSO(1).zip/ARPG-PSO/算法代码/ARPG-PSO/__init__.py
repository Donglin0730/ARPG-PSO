"""ARPG-PSO及其消融实现。"""
