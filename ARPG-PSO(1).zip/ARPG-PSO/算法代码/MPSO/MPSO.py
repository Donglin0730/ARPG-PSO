# -*- coding: utf-8 -*-
"""矩阵粒子群优化算法。"""

from __future__ import annotations

import numpy as np

from 算法代码.公共组件.pso_base import PSOBase


class MPSO(PSOBase):
    """每个粒子共享一组随机学习系数的矩阵PSO。"""

    def update(self, iteration, max_iterations):
        self._evaluate()
        inertia = 0.9 - 0.5 * iteration / max(1, max_iterations)
        random_cognitive = np.random.random((self.num_particles, 1))
        random_social = np.random.random((self.num_particles, 1))
        self.velocities = (
            inertia * self.velocities
            + 1.6
            * random_cognitive
            * (self.pbest_positions - self.positions)
            + 1.8
            * random_social
            * (self.gbest_position - self.positions)
        )
        self.positions += self.velocities
        self._clip()
        self.fitness_history.append(self.gbest_fitness)
        return self.gbest_fitness


__all__ = ["MPSO"]
