# -*- coding: utf-8 -*-
"""分层学习粒子群优化算法。"""

from __future__ import annotations

import numpy as np

from 算法代码.公共组件.pso_base import PSOBase


class SPSO(PSOBase):
    """使用互补学习因子的分层学习PSO。"""

    def update(self, iteration, max_iterations):
        fitness = self._evaluate()
        order = np.argsort(fitness)
        rank = np.empty(self.num_particles, dtype=float)
        rank[order] = np.arange(self.num_particles)
        cognitive_factor = 2.0 * rank / max(1, self.num_particles - 1)
        social_factor = 2.0 - cognitive_factor
        second_half = rank >= self.num_particles / 2
        cognitive_factor[second_half], social_factor[second_half] = (
            social_factor[second_half].copy(),
            cognitive_factor[second_half].copy(),
        )
        inertia = 1.0 - (iteration + 1) / max_iterations
        random_cognitive = np.random.random((self.num_particles, 1))
        random_social = np.random.random((self.num_particles, 1))
        self.velocities = (
            inertia * self.velocities
            + cognitive_factor[:, None]
            * random_cognitive
            * (self.pbest_positions - self.positions)
            + social_factor[:, None]
            * random_social
            * (self.gbest_position - self.positions)
        )
        maximum_velocity = 6.0 * (
            1.0 - np.log10(1.0 + 9.0 * iteration / 1000.0)
        )
        self.velocities = np.clip(
            self.velocities, -maximum_velocity, maximum_velocity
        )
        self.positions += self.velocities
        self._clip()
        self.fitness_history.append(self.gbest_fitness)
        return self.gbest_fitness


__all__ = ["SPSO"]
