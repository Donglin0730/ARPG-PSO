# -*- coding: utf-8 -*-
"""动态多群体粒子群优化算法。"""

from __future__ import annotations

import numpy as np

from 算法代码.公共组件.pso_base import PSOBase


class DMSPSO(PSOBase):
    """采用周期随机重组的动态多群体粒子群算法。"""

    def __init__(self, *args, group_size=5, regroup_period=5, **kwargs):
        super().__init__(*args, **kwargs)
        self.group_size = group_size
        self.regroup_period = regroup_period
        self.groups = []

    def _regroup(self):
        order = np.random.permutation(self.num_particles)
        self.groups = [
            order[index : index + self.group_size]
            for index in range(0, self.num_particles, self.group_size)
        ]

    def update(self, iteration, max_iterations):
        self._evaluate()
        if not self.groups or iteration % self.regroup_period == 0:
            self._regroup()
        targets = np.empty_like(self.positions)
        for group in self.groups:
            winner = group[np.argmin(self.pbest_fitness[group])]
            targets[group] = self.pbest_positions[winner]
        if iteration >= 0.9 * max_iterations:
            targets[:] = self.gbest_position
        inertia = 0.9 - 0.5 * iteration / max(1, max_iterations - 1)
        random_cognitive = np.random.random(self.positions.shape)
        random_social = np.random.random(self.positions.shape)
        self.velocities = (
            inertia * self.velocities
            + 1.49445
            * random_cognitive
            * (self.pbest_positions - self.positions)
            + 1.49445 * random_social * (targets - self.positions)
        )
        self.positions += self.velocities
        self._clip()
        self.fitness_history.append(self.gbest_fitness)
        return self.gbest_fitness


DMS_PSO = DMSPSO
__all__ = ["DMSPSO", "DMS_PSO"]
