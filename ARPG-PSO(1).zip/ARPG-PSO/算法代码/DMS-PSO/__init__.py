"""DMS-PSO实现。"""
