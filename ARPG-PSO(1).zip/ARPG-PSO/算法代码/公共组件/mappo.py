# -*- coding: utf-8 -*-
"""ARPG-PSO使用的共享策略网络和集中式价值网络。"""

from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Normal


DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


class ShieldedResidualMAPPO:
    """残差动作策略与集中式价值函数。"""

    def __init__(
        self,
        num_agents,
        state_dim=16,
        action_dim=4,
        learning_rate=3e-4,
        gamma=0.97,
        gae_lambda=0.95,
        clip_epsilon=0.2,
        entropy_coef=0.002,
        ppo_epochs=4,
        initial_log_std=-1.9,
        critic_state_dim=None,
    ):
        self.num_agents = num_agents
        self.state_dim = state_dim
        self.critic_state_dim = int(critic_state_dim or state_dim)
        if not 1 <= self.critic_state_dim <= self.state_dim:
            raise ValueError("critic_state_dim must be within actor state")
        self.action_dim = action_dim
        self.gamma = gamma
        self.gae_lambda = gae_lambda
        self.clip_epsilon = clip_epsilon
        self.entropy_coef = entropy_coef
        self.ppo_epochs = ppo_epochs

        self.actor = nn.Sequential(
            nn.Linear(state_dim, 96),
            nn.Tanh(),
            nn.Linear(96, 64),
            nn.Tanh(),
            nn.Linear(64, action_dim),
        ).to(DEVICE)
        nn.init.zeros_(self.actor[-1].weight)
        nn.init.zeros_(self.actor[-1].bias)
        self.log_std = nn.Parameter(
            torch.full((action_dim,), initial_log_std, device=DEVICE)
        )
        self.critic = nn.Sequential(
            nn.Linear(self.critic_state_dim * num_agents, 192),
            nn.Tanh(),
            nn.Linear(192, 96),
            nn.Tanh(),
            nn.Linear(96, 1),
        ).to(DEVICE)
        self.actor_optimizer = torch.optim.Adam(
            list(self.actor.parameters()) + [self.log_std], lr=learning_rate
        )
        self.critic_optimizer = torch.optim.Adam(
            self.critic.parameters(), lr=learning_rate
        )

        self.rollout = {
            key: []
            for key in (
                "states",
                "actions",
                "old_log_probs",
                "rewards",
                "values",
                "dones",
            )
        }
        self.sampled_action_count = 0
        self.executed_transition_count = 0
        self.training_update_count = 0
        self.last_ratio_mean = 1.0

    def clear_rollout(self):
        for values in self.rollout.values():
            values.clear()

    def _distribution(self, flat_states):
        mean = self.actor(flat_states)
        standard_deviation = self.log_std.exp().expand_as(mean)
        return Normal(mean, standard_deviation)

    @staticmethod
    def _squashed_log_prob(distribution, raw_action, action):
        correction = torch.log(1.0 - action.square() + 1e-6)
        return (
            distribution.log_prob(raw_action) - correction
        ).sum(dim=-1)

    def sample_actions(self, states):
        states_tensor = torch.as_tensor(
            states, dtype=torch.float32, device=DEVICE
        )
        particles = states_tensor.shape[0]
        flat_states = states_tensor.reshape(-1, self.state_dim)
        with torch.no_grad():
            distribution = self._distribution(flat_states)
            raw_action = distribution.sample()
            action = torch.tanh(raw_action)
            log_probability = self._squashed_log_prob(
                distribution, raw_action, action
            )
            critic_states = states_tensor[..., : self.critic_state_dim]
            value = self.critic(
                critic_states.reshape(particles, -1)
            ).squeeze(-1)
        self.sampled_action_count += particles * self.num_agents
        return (
            action.reshape(particles, self.num_agents, self.action_dim)
            .cpu()
            .numpy(),
            log_probability.reshape(particles, self.num_agents)
            .cpu()
            .numpy(),
            value.cpu().numpy(),
        )

    def values(self, states):
        states_tensor = torch.as_tensor(
            states, dtype=torch.float32, device=DEVICE
        )
        critic_states = states_tensor[..., : self.critic_state_dim]
        with torch.no_grad():
            return (
                self.critic(
                    critic_states.reshape(states_tensor.shape[0], -1)
                )
                .squeeze(-1)
                .cpu()
                .numpy()
            )

    def store_transition(
        self, states, actions, old_log_probs, rewards, values, dones
    ):
        self.rollout["states"].append(
            np.asarray(states, dtype=np.float32)
        )
        self.rollout["actions"].append(
            np.asarray(actions, dtype=np.float32)
        )
        self.rollout["old_log_probs"].append(
            np.asarray(old_log_probs, dtype=np.float32)
        )
        self.rollout["rewards"].append(
            np.asarray(rewards, dtype=np.float32)
        )
        self.rollout["values"].append(
            np.asarray(values, dtype=np.float32)
        )
        self.rollout["dones"].append(
            np.asarray(dones, dtype=np.float32)
        )
        self.executed_transition_count += int(np.asarray(rewards).size)

    def _gae(self, rewards, values, dones, bootstrap_values):
        advantages = np.zeros_like(rewards, dtype=np.float32)
        gae = np.zeros(rewards.shape[1], dtype=np.float32)
        next_values = np.asarray(bootstrap_values, dtype=np.float32)
        for step in reversed(range(rewards.shape[0])):
            mask = 1.0 - dones[step]
            delta = (
                rewards[step]
                + self.gamma * next_values * mask
                - values[step]
            )
            gae = (
                delta
                + self.gamma * self.gae_lambda * mask * gae
            )
            advantages[step] = gae
            next_values = values[step]
        return advantages, advantages + values

    def _evaluate(self, states, actions):
        time_steps, particles, agents, _ = states.shape
        flat_states = states.reshape(-1, self.state_dim)
        flat_actions = torch.clamp(
            actions.reshape(-1, self.action_dim), -0.999999, 0.999999
        )
        raw_actions = torch.atanh(flat_actions)
        distribution = self._distribution(flat_states)
        log_probabilities = self._squashed_log_prob(
            distribution, raw_actions, flat_actions
        ).reshape(time_steps * particles, agents)
        entropy = distribution.entropy().sum(dim=-1).reshape(
            time_steps * particles, agents
        )
        critic_states = states[..., : self.critic_state_dim].reshape(
            time_steps * particles, -1
        )
        values = self.critic(critic_states).squeeze(-1)
        return log_probabilities, entropy, values

    def update(self, next_states, terminal=False):
        if not self.rollout["states"]:
            return 0.0, 0.0

        states_array = np.asarray(
            self.rollout["states"], dtype=np.float32
        )
        actions_array = np.asarray(
            self.rollout["actions"], dtype=np.float32
        )
        old_log_probabilities = np.asarray(
            self.rollout["old_log_probs"], dtype=np.float32
        )
        rewards = np.asarray(self.rollout["rewards"], dtype=np.float32)
        values = np.asarray(self.rollout["values"], dtype=np.float32)
        dones = np.asarray(self.rollout["dones"], dtype=np.float32)
        bootstrap = (
            np.zeros(rewards.shape[1], dtype=np.float32)
            if terminal
            else self.values(next_states)
        )
        advantages, returns = self._gae(
            rewards, values, dones, bootstrap
        )
        normalised_advantages = (
            advantages - advantages.mean()
        ) / (advantages.std() + 1e-8)

        states = torch.as_tensor(
            states_array, dtype=torch.float32, device=DEVICE
        )
        actions = torch.as_tensor(
            actions_array, dtype=torch.float32, device=DEVICE
        )
        old_log_probabilities = torch.as_tensor(
            old_log_probabilities.reshape(-1, self.num_agents),
            dtype=torch.float32,
            device=DEVICE,
        )
        actor_advantages = torch.as_tensor(
            normalised_advantages.reshape(-1, 1),
            dtype=torch.float32,
            device=DEVICE,
        ).expand(-1, self.num_agents)
        returns_tensor = torch.as_tensor(
            returns.reshape(-1), dtype=torch.float32, device=DEVICE
        )

        actor_loss_total = 0.0
        critic_loss_total = 0.0
        for _ in range(self.ppo_epochs):
            new_log_probabilities, entropy, value_predictions = (
                self._evaluate(states, actions)
            )
            ratio = torch.exp(
                new_log_probabilities - old_log_probabilities
            )
            clipped = torch.clamp(
                ratio,
                1.0 - self.clip_epsilon,
                1.0 + self.clip_epsilon,
            )
            surrogate = torch.minimum(
                ratio * actor_advantages,
                clipped * actor_advantages,
            )
            actor_loss = -(
                surrogate.mean()
                + self.entropy_coef * entropy.mean()
            )
            critic_loss = F.mse_loss(value_predictions, returns_tensor)

            self.actor_optimizer.zero_grad()
            actor_loss.backward()
            nn.utils.clip_grad_norm_(
                list(self.actor.parameters()) + [self.log_std], 0.5
            )
            self.actor_optimizer.step()
            self.critic_optimizer.zero_grad()
            critic_loss.backward()
            nn.utils.clip_grad_norm_(self.critic.parameters(), 0.5)
            self.critic_optimizer.step()

            self.last_ratio_mean = float(ratio.detach().mean().cpu())
            actor_loss_total += float(actor_loss.detach().cpu())
            critic_loss_total += float(critic_loss.detach().cpu())

        self.training_update_count += 1
        self.clear_rollout()
        return (
            actor_loss_total / self.ppo_epochs,
            critic_loss_total / self.ppo_epochs,
        )


__all__ = ["ShieldedResidualMAPPO"]
