# -*- coding: utf-8 -*-
from __future__ import annotations

import numpy as np

from model import init_base_station, objective_function, update_coverage


class PSOBase:
    """矩阵形式PSO对比算法的共享基础实现。"""

    def __init__(self, p, special_area, num_particles=20):
        self.p = p
        self.special_area = special_area
        self.num_particles = num_particles
        self.num_uavs = p["num_base_stations"]
        self.dim = self.num_uavs * 3
        self.size = p["size"]
        self.h_min, self.h_max = p["h_min"], p["h_max"]
        one_low = np.array([0.0, 0.0, self.h_min])
        one_high = np.array([self.size - 1.0, self.size - 1.0, self.h_max])
        self.lower = np.tile(one_low, self.num_uavs)
        self.upper = np.tile(one_high, self.num_uavs)
        self.span = self.upper - self.lower
        self.positions = np.random.uniform(
            self.lower, self.upper, size=(num_particles, self.dim)
        )
        self.velocities = np.zeros_like(self.positions)
        self.pbest_positions = self.positions.copy()
        self.pbest_fitness = np.full(num_particles, np.inf)
        self.gbest_position = None
        self.gbest_fitness = np.inf
        self.fitness_history = []
        self.current_fitness = np.full(num_particles, np.inf)
        self.evaluation_count = 0

    def evaluate_particle(self, flat_position):
        self.evaluation_count += 1
        position = np.asarray(flat_position).reshape(self.num_uavs, 3)
        grid = np.zeros((self.size, self.size), dtype=float)
        coverage = np.zeros((self.size, self.size), dtype=int)
        stations = [
            init_base_station(row[2], (row[0], row[1])) for row in position
        ]
        update_coverage(grid, coverage, stations, self.size)
        return objective_function(
            self.size, grid, coverage, self.special_area
        )

    def _evaluate(self):
        fitness = np.array(
            [self.evaluate_particle(position) for position in self.positions]
        )
        improved = fitness < self.pbest_fitness
        self.pbest_fitness[improved] = fitness[improved]
        self.pbest_positions[improved] = self.positions[improved]
        best_index = int(np.argmin(fitness))
        if fitness[best_index] < self.gbest_fitness:
            self.gbest_fitness = float(fitness[best_index])
            self.gbest_position = self.positions[best_index].copy()
        self.current_fitness = fitness
        return fitness

    def _clip(self):
        self.positions = np.clip(self.positions, self.lower, self.upper)

    def update(self, iteration, max_iterations):
        raise NotImplementedError

    def get_best_solution(self):
        return (
            self.gbest_position.reshape(self.num_uavs, 3).tolist(),
            self.gbest_fitness,
        )
