# -*- coding: utf-8 -*-
"""综合学习粒子群优化算法。"""

from __future__ import annotations

import numpy as np

from 算法代码.公共组件.pso_base import PSOBase


class CLPSO(PSOBase):
    """使用逐维个体最优示范者的综合学习粒子群算法。"""

    def __init__(self, *args, refresh_gap=7, **kwargs):
        super().__init__(*args, **kwargs)
        indices = np.arange(self.num_particles)
        denominator = np.exp(10.0) - 1.0
        self.pc = 0.05 + 0.45 * (
            np.exp(10.0 * indices / max(1, self.num_particles - 1)) - 1.0
        ) / denominator
        self.refresh_gap = refresh_gap
        self.stagnation = np.zeros(self.num_particles, dtype=int)
        self.exemplar = np.tile(indices[:, None], (1, self.dim))

    def _refresh(self, particle):
        learn = np.random.random(self.dim) < self.pc[particle]
        if not learn.any():
            learn[np.random.randint(self.dim)] = True
        for dimension in np.where(learn)[0]:
            first, second = np.random.choice(
                self.num_particles, 2, replace=False
            )
            self.exemplar[particle, dimension] = (
                first
                if self.pbest_fitness[first] < self.pbest_fitness[second]
                else second
            )
        self.stagnation[particle] = 0

    def update(self, iteration, max_iterations):
        previous = self.pbest_fitness.copy()
        self._evaluate()
        self.stagnation = np.where(
            self.pbest_fitness < previous, 0, self.stagnation + 1
        )
        for particle in range(self.num_particles):
            if iteration == 0 or self.stagnation[particle] >= self.refresh_gap:
                self._refresh(particle)
        exemplar_positions = np.empty_like(self.positions)
        dimensions = np.arange(self.dim)
        for particle in range(self.num_particles):
            exemplar_positions[particle] = self.pbest_positions[
                self.exemplar[particle, dimensions], dimensions
            ]
        inertia = 0.9 - 0.5 * iteration / max(1, max_iterations - 1)
        self.velocities = (
            inertia * self.velocities
            + 1.49445
            * np.random.random(self.positions.shape)
            * (exemplar_positions - self.positions)
        )
        self.positions += self.velocities
        self._clip()
        self.fitness_history.append(self.gbest_fitness)
        return self.gbest_fitness


__all__ = ["CLPSO"]
