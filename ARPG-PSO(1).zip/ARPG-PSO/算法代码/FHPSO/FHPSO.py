# -*- coding: utf-8 -*-
"""四层级粒子群优化算法。"""

from __future__ import annotations

import numpy as np

from 算法代码.公共组件.pso_base import PSOBase


class FHPSO(PSOBase):
    """使用四层种群和层级引导信息更新粒子的FHPSO。"""

    def update(self, iteration, max_iterations):
        fitness = self._evaluate()
        order = np.argsort(fitness)
        self.positions = self.positions[order]
        self.velocities = self.velocities[order]
        self.current_fitness = self.current_fitness[order]
        self.pbest_positions = self.pbest_positions[order]
        self.pbest_fitness = self.pbest_fitness[order]

        if self.num_particles < 10:
            cuts = np.linspace(
                0, self.num_particles, 5, dtype=int
            ).tolist()
        else:
            cuts = [
                0,
                int(0.1 * self.num_particles),
                int(0.3 * self.num_particles),
                int(0.6 * self.num_particles),
                self.num_particles,
            ]
        centers = []
        high_centers = []
        high_masks = []
        for group in range(4):
            start, end = cuts[group], cuts[group + 1]
            block = self.positions[start:end]
            block_fitness = self.current_fitness[start:end]
            center = block.reshape(-1, 3).mean(axis=0)
            high_mask = block_fitness <= block_fitness.mean()
            high = block[high_mask] if high_mask.any() else block
            high_center = high.reshape(-1, 3).mean(axis=0)
            centers.append(np.tile(center, self.num_uavs))
            high_centers.append(np.tile(high_center, self.num_uavs))
            high_masks.append(high_mask)

        inertia, cognitive_factor, social_factor = 0.9, 2.0, 2.0
        for group in range(4):
            start, end = cuts[group], cuts[group + 1]
            for local_index, particle in enumerate(range(start, end)):
                random_cognitive = np.random.random()
                random_social = np.random.random()
                if high_masks[group][local_index]:
                    previous = max(0, group - 1)
                    random_group = np.random.random()
                    self.velocities[particle] = (
                        inertia * self.velocities[particle]
                        + cognitive_factor
                        * random_cognitive
                        * (
                            self.pbest_positions[particle]
                            - self.positions[particle]
                        )
                        + social_factor
                        * random_social
                        * (self.gbest_position - self.positions[particle])
                        + random_group
                        * (centers[previous] - self.positions[particle])
                    )
                else:
                    self.velocities[particle] = (
                        inertia * self.velocities[particle]
                        + cognitive_factor
                        * random_cognitive
                        * (
                            self.pbest_positions[particle]
                            - self.positions[particle]
                        )
                        + random_social
                        * (high_centers[group] - self.positions[particle])
                    )
        maximum_velocity = 0.35 * self.span
        self.velocities = np.clip(
            self.velocities, -maximum_velocity, maximum_velocity
        )
        self.positions += self.velocities
        self._clip()
        self.fitness_history.append(self.gbest_fitness)
        return self.gbest_fitness


__all__ = ["FHPSO"]
