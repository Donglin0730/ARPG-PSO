from importlib import import_module

from exp_config import TARGET


PurePSO = import_module("算法代码.PSO.PSO").PurePSO
MPSO = import_module("算法代码.MPSO.MPSO").MPSO
CLPSO = import_module("算法代码.CLPSO.CLPSO").CLPSO
DMSPSO = import_module("算法代码.DMS-PSO.DMS_PSO").DMSPSO
SPSO = import_module("算法代码.SPSO.SPSO").SPSO
MPSORL = import_module("算法代码.MPSORL.MPSORL").MPSORL
AFMPSO = import_module("算法代码.AFMPSO.AFMPSO").AFMPSO
AMSEPSO = import_module("算法代码.AMSEPSO.AMSEPSO").AMSEPSO
FHPSO = import_module("算法代码.FHPSO.FHPSO").FHPSO
ARPG_MODULE = import_module("算法代码.ARPG-PSO.ARPG_PSO")
ARPG_PSO_v31 = ARPG_MODULE.ARPG_PSO_v31
ARPG_PSO_v31_Ablation = import_module(
    "算法代码.ARPG-PSO.ablation"
).ARPG_PSO_v31_Ablation


PAPER_ALGORITHM_CLASSES = {
    "PSO": PurePSO,
    "MPSO": MPSO,
    "CLPSO": CLPSO,
    "DMS-PSO": DMSPSO,
    "SPSO": SPSO,
    "MPSORL": MPSORL,
    "AFMPSO": AFMPSO,
    "AMSEPSO": AMSEPSO,
    "FHPSO": FHPSO,
    TARGET: ARPG_PSO_v31,
}


__all__ = [
    "PAPER_ALGORITHM_CLASSES",
    "ARPG_PSO_v31",
    "ARPG_PSO_v31_Ablation",
]
