"""AMSEPSO实现。"""
