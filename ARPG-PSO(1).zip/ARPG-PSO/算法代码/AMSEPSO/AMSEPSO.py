# -*- coding: utf-8 -*-
"""自适应多策略增强粒子群优化算法。"""

from __future__ import annotations

import numpy as np

from 算法代码.公共组件.pso_base import PSOBase


class AMSEPSO(PSOBase):
    """根据种群多样性状态切换学习策略的AMSEPSO。"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.chaos = float(np.random.random())
        self.pworst_positions = self.positions.copy()
        self.pworst_fitness = np.full(self.num_particles, -np.inf)

    def update(self, iteration, max_iterations):
        fitness = self._evaluate()
        worse = fitness > self.pworst_fitness
        self.pworst_fitness[worse] = fitness[worse]
        self.pworst_positions[worse] = self.positions[worse]

        progress = iteration / max(1, max_iterations - 1)
        inertia = 0.9 - 0.5 * progress
        cognitive_factor = 2.5 - self.chaos * progress
        social_factor = 0.5 + self.chaos * progress
        coefficient = np.random.uniform(0.9, 1.08)
        chaos = self.chaos
        raw = (
            coefficient * 7.86 * chaos
            + 23.31 * chaos**2
            + 28.75 * chaos**3
            + 13.28 * chaos**4
            + 0.5 * chaos**5
        )
        self.chaos = float(np.mod(abs(raw), 1.0))

        top = max(2, int(np.ceil(0.2 * self.num_particles)))
        elite_indices = np.argsort(fitness)[:top]
        first, second = np.random.choice(elite_indices, 2, replace=False)
        best_candidate = (
            first
            if self.pbest_fitness[first] <= self.pbest_fitness[second]
            else second
        )
        candidate_best = self.positions[best_candidate]
        candidate_fitness = self.pbest_fitness[best_candidate]
        mean_best = self.pbest_positions.mean(axis=0)

        global_variance = max(float(np.var(self.gbest_position)), 1e-8)
        worst_index = int(np.argmax(self.pworst_fitness))
        global_worst = self.pworst_positions[worst_index]
        worst_variance = max(float(np.var(global_worst)), 1e-8)
        distance_best = np.var(
            self.pbest_positions - self.gbest_position, axis=1
        ) / global_variance
        distance_worst = np.var(
            self.pworst_positions - global_worst, axis=1
        ) / worst_variance
        state = int(
            np.sum(distance_worst <= distance_best)
            - np.sum(distance_best < distance_worst)
        )
        threshold = 0.3 * self.num_particles

        random_cognitive = np.random.random((self.num_particles, 1))
        random_social = np.random.random((self.num_particles, 1))
        if state > threshold:
            cognitive = self.pbest_positions
            social = np.broadcast_to(
                self.gbest_position, self.positions.shape
            )
        elif state < -threshold:
            cognitive = self.pbest_positions.copy()
            weak = self.pbest_fitness > candidate_fitness
            cognitive[weak] = candidate_best
            social = np.broadcast_to(mean_best, self.positions.shape)
        else:
            cognitive = self.pbest_positions
            social = np.broadcast_to(mean_best, self.positions.shape)
        self.velocities = (
            inertia * self.velocities
            + cognitive_factor
            * random_cognitive
            * (cognitive - self.positions)
            + social_factor
            * random_social
            * (social - self.positions)
        )
        maximum_velocity = 0.35 * self.span
        self.velocities = np.clip(
            self.velocities, -maximum_velocity, maximum_velocity
        )
        self.positions += self.velocities
        self._clip()
        self.fitness_history.append(self.gbest_fitness)
        return self.gbest_fitness


__all__ = ["AMSEPSO"]
