"""AFMPSO实现。"""
