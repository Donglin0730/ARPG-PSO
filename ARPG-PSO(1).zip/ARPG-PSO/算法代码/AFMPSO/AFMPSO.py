# -*- coding: utf-8 -*-
"""自适应融合模型粒子群优化算法。"""

from __future__ import annotations

import numpy as np

from 算法代码.公共组件.pso_base import PSOBase


class AFMPSO(PSOBase):
    """根据当前优良粒子构造学习模型的AFMPSO。"""

    def update(self, iteration, max_iterations):
        fitness = self._evaluate()
        count = int(self.num_particles / (iteration + 1))
        if count:
            indices = np.argsort(fitness)[:count]
            study_model = self.positions[indices].mean(axis=0)
        else:
            study_model = self.gbest_position
        inertia = 2.0 / (iteration + 1)
        shape = (self.num_particles, 1)
        random_cognitive, random_social, random_model = (
            np.random.random(shape) for _ in range(3)
        )
        self.velocities = (
            inertia * self.velocities
            + 2.0
            * random_cognitive
            * (self.pbest_positions - self.positions)
            + 2.0
            * random_social
            * (self.gbest_position - self.positions)
            + random_model * (study_model - self.positions)
        )
        self.positions += self.velocities
        self._clip()
        self.fitness_history.append(self.gbest_fitness)
        return self.gbest_fitness


__all__ = ["AFMPSO"]
