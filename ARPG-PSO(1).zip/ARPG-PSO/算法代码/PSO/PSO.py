# -*- coding: utf-8 -*-
import os
import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from model import (canshu, init_base_station, update_coverage,
                   objective_function, calculate_coverage_and_uniformity,
                   calibrate_normalization, load_special_area, save_special_area)
from tetromino_generator import generate_special_area

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


class PurePSO:
    """纯PSO算法"""

    def __init__(self, p, special_area, num_particles=20):
        self.p = p
        self.special_area = special_area
        self.num_particles = num_particles
        self.num_uavs = p['num_base_stations']
        self.size = p['size']
        self.h_min, self.h_max = p['h_min'], p['h_max']

        # 初始化种群
        self.positions, self.velocities = self._initialize_population()

        # 个体最优 (pbest)
        self.pbest_positions = [pos.copy() for pos in self.positions]
        self.pbest_fitness = np.full(num_particles, np.inf)

        # 全局最优 (gbest)
        self.gbest_position = None
        self.gbest_fitness = np.inf

        # 标准 PSO 参数：使用固定惯性权重，区别于线性递减权重 PSO。
        self.w = 0.7
        self.c1 = 1.6  # 个体认知系数
        self.c2 = 1.8  # 社会认知系数

        # 历史记录
        self.fitness_history = []
        # Number of objective-function evaluations performed by the optimiser.
        self.evaluation_count = 0

    def _initialize_population(self):
        """初始化粒子位置和速度"""
        positions = []
        velocities = []

        for _ in range(self.num_particles):
            # 随机位置
            pos = [[np.random.uniform(0, self.size),
                    np.random.uniform(0, self.size),
                    np.random.uniform(self.h_min, self.h_max)]
                   for _ in range(self.num_uavs)]
            positions.append(pos)

            # 随机速度
            vel = [[0.0, 0.0, 0.0] for _ in range(self.num_uavs)]
            velocities.append(vel)

        return positions, velocities

    def evaluate_particle(self, particle_pos):
        """评估单个粒子的适应度"""
        self.evaluation_count += 1
        grid = np.zeros((self.size, self.size), dtype=float)
        coverage = np.zeros((self.size, self.size), dtype=int)

        bss = [init_base_station(particle_pos[i][2],
                                 (particle_pos[i][0], particle_pos[i][1]))
               for i in range(self.num_uavs)]
        update_coverage(grid, coverage, bss, self.size)

        fitness = objective_function(self.size, grid, coverage, self.special_area)
        return fitness, grid, coverage

    def update(self, iteration, max_iterations):
        """执行PSO更新"""
        w = self.w

        # 评估所有粒子
        current_fitness = []

        for i in range(self.num_particles):
            fitness, grid, coverage = self.evaluate_particle(self.positions[i])
            current_fitness.append(fitness)

            # 更新个体最优
            if fitness < self.pbest_fitness[i]:
                self.pbest_fitness[i] = fitness
                self.pbest_positions[i] = [pos.copy() for pos in self.positions[i]]

            # 更新全局最优
            if fitness < self.gbest_fitness:
                self.gbest_fitness = fitness
                self.gbest_position = [pos.copy() for pos in self.positions[i]]

        # 更新速度和位置
        for i in range(self.num_particles):
            r1, r2 = np.random.rand(), np.random.rand()

            for j in range(self.num_uavs):
                for k in range(3):  # x, y, h
                    # 速度更新
                    self.velocities[i][j][k] = (
                        w * self.velocities[i][j][k] +
                        self.c1 * r1 * (self.pbest_positions[i][j][k] - self.positions[i][j][k]) +
                        self.c2 * r2 * (self.gbest_position[j][k] - self.positions[i][j][k])
                    )

                    # 位置更新
                    self.positions[i][j][k] += self.velocities[i][j][k]

                    # 边界约束
                    if k < 2:  # x, y
                        self.positions[i][j][k] = np.clip(self.positions[i][j][k], 0, self.size - 1)
                    else:  # h
                        self.positions[i][j][k] = np.clip(self.positions[i][j][k], self.h_min, self.h_max)

        # 记录历史
        self.fitness_history.append(self.gbest_fitness)

        return self.gbest_fitness

    def get_best_solution(self):
        """获取当前最优解"""
        return self.gbest_position, self.gbest_fitness


def main():
    """主函数"""
    print("=" * 60)
    print("纯PSO算法优化（对比基线）")
    print("=" * 60)

    # 参数配置
    p = canshu()
    p['max_iterations'] = 100

    # 加载或生成重点区域
    special_area = load_special_area()
    print(f"重点区域占比: {100.0 * special_area.sum() / special_area.size:.1f}%")

    # 标定标准化
    calibrate_normalization(p['size'], special_area, num_samples=60, seed=0)

    # 创建纯PSO优化器
    pso = PurePSO(p, special_area, num_particles=20)

    # 训练
    history = {'fitness': [], 'coverage': [], 'special_coverage': [], 'general_coverage': []}
    start_time = time.time()

    for iteration in range(p['max_iterations']):
        fitness = pso.update(iteration, p['max_iterations'])

        # 计算覆盖率
        best_pos, best_fitness = pso.get_best_solution()
        grid = np.zeros((p['size'], p['size']), dtype=float)
        coverage = np.zeros((p['size'], p['size']), dtype=int)
        bss = [init_base_station(best_pos[i][2], (best_pos[i][0], best_pos[i][1]))
               for i in range(p['num_base_stations'])]
        update_coverage(grid, coverage, bss, p['size'])

        total_cov, spec_cov, gen_cov, std_spec, std_gen = calculate_coverage_and_uniformity(
            p['size'], grid, coverage, special_area
        )

        history['fitness'].append(fitness)
        history['coverage'].append(total_cov)
        history['special_coverage'].append(spec_cov)
        history['general_coverage'].append(gen_cov)

        # 打印进度
        if iteration % 10 == 0 or iteration == p['max_iterations'] - 1:
            print(f"Iter {iteration}: Fitness={fitness:.4f}, Cov={total_cov:.2f}%, SpecCov={spec_cov:.2f}%")

    training_time = time.time() - start_time

    # 输出结果
    print("\n" + "="*60)
    print("纯PSO训练结果：")
    print(f"训练时间: {training_time:.2f}秒")
    print(f"最终适应度: {history['fitness'][-1]:.4f}")
    print(f"最终覆盖率: {history['coverage'][-1]:.2f}%")
    print(f"重点区域覆盖率: {history['special_coverage'][-1]:.2f}%")
    print(f"常规区域覆盖率: {history['general_coverage'][-1]:.2f}%")

    return history


if __name__ == "__main__":
    main()
