# -*- coding: utf-8 -*-
"""基于Q学习策略选择的多策略粒子群优化算法。"""

from __future__ import annotations

import numpy as np

from 算法代码.公共组件.pso_base import PSOBase


class MPSORL(PSOBase):
    """采用五种适应度状态和四种移动策略的MPSORL。"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.q_table = np.zeros((5, 4), dtype=float)
        self.previous_states = None
        self.previous_actions = None

    def _states(self, fitness):
        order = np.argsort(fitness)
        states = np.empty(self.num_particles, dtype=int)
        boundaries = np.array([0.10, 0.30, 0.60, 0.85, 1.0])
        ranks = (np.arange(self.num_particles) + 1) / self.num_particles
        states[order] = np.searchsorted(boundaries, ranks, side="left")
        return states

    def _ring_targets(self):
        targets = np.empty_like(self.positions)
        for particle in range(self.num_particles):
            neighbours = np.array(
                [
                    (particle - 1) % self.num_particles,
                    particle,
                    (particle + 1) % self.num_particles,
                ]
            )
            winner = neighbours[
                np.argmin(self.pbest_fitness[neighbours])
            ]
            targets[particle] = self.pbest_positions[winner]
        return targets

    def update(self, iteration, max_iterations):
        fitness = self._evaluate()
        states = self._states(fitness)
        if self.previous_states is not None:
            rewards = (states < self.previous_states).astype(float)
            for state, action, reward, next_state in zip(
                self.previous_states,
                self.previous_actions,
                rewards,
                states,
            ):
                target = reward + 0.8 * np.max(self.q_table[next_state])
                self.q_table[state, action] += 0.2 * (
                    target - self.q_table[state, action]
                )
        epsilon = 0.20 - 0.15 * iteration / max(1, max_iterations - 1)
        actions = np.argmax(self.q_table[states], axis=1)
        explore = np.random.random(self.num_particles) < epsilon
        actions[explore] = np.random.randint(0, 4, explore.sum())

        inertia = 0.9 - 0.5 * iteration / max(1, max_iterations - 1)
        ring = self._ring_targets()
        new_velocity = self.velocities.copy()
        for particle, action in enumerate(actions):
            random_cognitive = np.random.random(self.dim)
            random_social = np.random.random(self.dim)
            if action == 0:
                social = self.gbest_position
                new_velocity[particle] = (
                    inertia * self.velocities[particle]
                    + 1.6
                    * random_cognitive
                    * (
                        self.pbest_positions[particle]
                        - self.positions[particle]
                    )
                    + 1.8
                    * random_social
                    * (social - self.positions[particle])
                )
            elif action == 1:
                new_velocity[particle] = (
                    inertia * self.velocities[particle]
                    + 1.7
                    * random_cognitive
                    * (
                        self.pbest_positions[particle]
                        - self.positions[particle]
                    )
                    + 1.7
                    * random_social
                    * (ring[particle] - self.positions[particle])
                )
            elif action == 2:
                first, second = np.random.choice(
                    self.num_particles, 2, replace=False
                )
                exemplar = self.pbest_positions[
                    first
                    if self.pbest_fitness[first] < self.pbest_fitness[second]
                    else second
                ]
                mask = np.random.random(self.dim) < 0.5
                target = np.where(
                    mask, exemplar, self.pbest_positions[particle]
                )
                new_velocity[particle] = (
                    inertia * self.velocities[particle]
                    + 1.9
                    * random_cognitive
                    * (target - self.positions[particle])
                )
            else:
                first, second = np.random.choice(
                    self.num_particles, 2, replace=False
                )
                differential = (
                    self.pbest_positions[first]
                    - self.pbest_positions[second]
                )
                new_velocity[particle] = (
                    0.7 * self.velocities[particle]
                    + 0.8
                    * random_cognitive
                    * (self.gbest_position - self.positions[particle])
                    + 0.5 * random_social * differential
                )
        maximum_velocity = 0.25 * self.span
        self.velocities = np.clip(
            new_velocity, -maximum_velocity, maximum_velocity
        )
        self.positions += self.velocities
        self._clip()
        self.previous_states = states.copy()
        self.previous_actions = actions.copy()
        self.fitness_history.append(self.gbest_fitness)
        return self.gbest_fitness


__all__ = ["MPSORL"]
