"""实验运行器共用的场景配置与指标复算函数。"""

from __future__ import annotations

import numpy as np

import model
from model import (
    _raw_objectives,
    calculate_coverage_and_uniformity,
    canshu,
    configure_objective_weights,
    init_base_station,
    update_coverage,
)


def configure_scenario(
    num_uavs: int,
    threshold_db: float,
    max_function_evaluations: int,
    objective_weights=None,
) -> dict:
    """设置 UAV 数量、SINR 门限和最大函数评价次数。"""
    parameters = canshu()
    parameters["num_base_stations"] = int(num_uavs)
    parameters["gamma_th_db"] = float(threshold_db)
    parameters["N0_dbm"] = -110.0
    parameters["max_function_evaluations"] = int(max_function_evaluations)
    model._P.update(parameters)
    if objective_weights is not None:
        configure_objective_weights(objective_weights)
        parameters.update({
            key: model._P[key] for key in ("w1", "ws", "w2", "w3")
        })
    return parameters


def final_metrics(best_position, parameters: dict, special_area: np.ndarray):
    """重新评价部署方案并返回覆盖率及四个原始目标项。"""
    size = parameters["size"]
    grid = np.zeros((size, size), dtype=float)
    coverage = np.zeros((size, size), dtype=int)
    stations = [
        init_base_station(row[2], (row[0], row[1]))
        for row in best_position
    ]
    update_coverage(grid, coverage, stations, size)
    total, special, general, _, _ = calculate_coverage_and_uniformity(
        size, grid, coverage, special_area
    )
    f1, fs, f2, f3 = _raw_objectives(size, grid, coverage, special_area)
    return total, special, general, f1, fs, f2, f3
