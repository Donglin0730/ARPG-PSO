"""CLPSO实现。"""
