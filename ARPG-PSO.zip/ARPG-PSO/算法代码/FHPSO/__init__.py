"""FHPSO实现。"""
