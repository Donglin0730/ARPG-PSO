"""MPSORL实现。"""
